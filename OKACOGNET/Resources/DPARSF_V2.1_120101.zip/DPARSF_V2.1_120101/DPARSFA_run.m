function [Error]=DPARSFA_run(AutoDataProcessParameter)
% FORMAT [Error]=DPARSFA_run(AutoDataProcessParameter)
% Input:
%   AutoDataProcessParameter - the parameters for auto data processing
% Output:
%   The processed data that you want.
%___________________________________________________________________________
% Written by YAN Chao-Gan 090306.
% State Key Laboratory of Cognitive Neuroscience and Learning, Beijing Normal University, China, 100875
% The Nathan Kline Institute for Psychiatric Research, 140 Old Orangeburg Road, Orangeburg, NY 10962; Child Mind Institute, 445 Park Avenue, New York, NY 10022; The Phyllis Green and Randolph Cowen Institute for Pediatric Neuroscience, New York University Child Study Center, New York, NY 10016
% ycg.yan@gmail.com
% Modified by YAN Chao-Gan 090712, added the function of mReHo - 1, mALFF - 1, mfALFF -1.
% Modified by YAN Chao-Gan 090901, added the function of smReHo, remove variable first time points.
% Modified by YAN Chao-Gan, 090925, SPM8 compatible.
% Modified by YAN Chao-Gan 091001, Generate the pictures for checking normalization.
% Modified by YAN Chao-Gan 091111. 1. Use different Affine Regularisation in Segmentation: East Asian brains (eastern) or European brains (mni). 2. Added a checkbox for removing first time points. 3.Added popup menu to delete selected subject by right click. 4. Close wait bar when program finished.
% Modified by YAN Chao-Gan 091212. Also can regress out other covariates.
% Modified by YAN Chao-Gan 100201. Fixed the bug in converting DICOM files to NIfTI files when DPARSF stored under C:\Program Files\Matlab\Toolbox.
% Modified by YAN Chao-Gan, 100420. Release the memory occupied by "hdr" after converting one participant's Functional DICOM files to NIFTI images in linux. Make compatible with missing parameters. Fixed a bug in generating the pictures for checking normalizationdisplaying when overlay with different bounding box from those of underlay in according to rest_sliceviewer.m.
% Modified by YAN Chao-Gan, 100510. Fixed a bug in converting DICOM files to NIfTI in Windows 7, thanks to Prof. Chris Rorden's new dcm2nii. Now will detect if co* T1 image is exist before normalization by using T1 image unified segmentation.
% Modified by YAN Chao-Gan, 101025. Changed for Data Processing Assistant for Resting-State fMRI (DPARSF) Advanced Edition (alias: DPARSFA).
% Last Modified by YAN Chao-Gan, 120101. DARTEL, multiplse sessions, reorient, .nii.gz files and so on added.

if ischar(AutoDataProcessParameter)  %If inputed a .mat file name. (Cfg inside)
    load(AutoDataProcessParameter);
    AutoDataProcessParameter=Cfg;
end

[ProgramPath, fileN, extn] = fileparts(which('DPARSFA_run.m'));
AutoDataProcessParameter.SubjectNum=length(AutoDataProcessParameter.SubjectID);
Error=[];
addpath([ProgramPath,filesep,'Subfunctions']);

[SPMversion,c]=spm('Ver');
SPMversion=str2double(SPMversion(end));


%Make compatible with missing parameters. YAN Chao-Gan, 100420.
if ~isfield(AutoDataProcessParameter,'DataProcessDir')
    AutoDataProcessParameter.DataProcessDir=AutoDataProcessParameter.WorkingDir;
end
if isfield(AutoDataProcessParameter,'TR')
    AutoDataProcessParameter.SliceTiming.TR=AutoDataProcessParameter.TR;
    AutoDataProcessParameter.SliceTiming.TA=AutoDataProcessParameter.SliceTiming.TR-(AutoDataProcessParameter.SliceTiming.TR/AutoDataProcessParameter.SliceTiming.SliceNumber);
    AutoDataProcessParameter.Filter.ASamplePeriod=AutoDataProcessParameter.TR;
    AutoDataProcessParameter.CalALFF.ASamplePeriod=AutoDataProcessParameter.TR;
    AutoDataProcessParameter.CalfALFF.ASamplePeriod=AutoDataProcessParameter.TR;
end
if ~isfield(AutoDataProcessParameter,'FunctionalSessionNumber')
    AutoDataProcessParameter.FunctionalSessionNumber=1; 
end
if ~isfield(AutoDataProcessParameter,'IsNeedConvertFunDCM2IMG')
    AutoDataProcessParameter.IsNeedConvertFunDCM2IMG=0; 
end
if ~isfield(AutoDataProcessParameter,'IsNeedConvert4DFunInto3DImg')
    AutoDataProcessParameter.IsNeedConvert4DFunInto3DImg=0; 
end
if ~isfield(AutoDataProcessParameter,'RemoveFirstTimePoints')
    AutoDataProcessParameter.RemoveFirstTimePoints=0; 
end
if ~isfield(AutoDataProcessParameter,'IsSliceTiming')
    AutoDataProcessParameter.IsSliceTiming=0; 
end
if ~isfield(AutoDataProcessParameter,'IsRealign')
    AutoDataProcessParameter.IsRealign=0; 
end
if ~isfield(AutoDataProcessParameter,'IsNeedReorientFunImgInteractively')
    AutoDataProcessParameter.IsNeedReorientFunImgInteractively=0; 
end
if ~isfield(AutoDataProcessParameter,'IsNeedConvertT1DCM2IMG')
    AutoDataProcessParameter.IsNeedConvertT1DCM2IMG=0; 
end
if ~isfield(AutoDataProcessParameter,'IsNeedUnzipT1IntoT1Img')
    AutoDataProcessParameter.IsNeedUnzipT1IntoT1Img=0; 
end
if ~isfield(AutoDataProcessParameter,'IsNeedReorientCropT1Img')
    AutoDataProcessParameter.IsNeedReorientCropT1Img=0; 
end
if ~isfield(AutoDataProcessParameter,'IsNeedReorientT1ImgInteractively')
    AutoDataProcessParameter.IsNeedReorientT1ImgInteractively=0; 
end
if ~isfield(AutoDataProcessParameter,'IsNeedT1CoregisterToFun')
    AutoDataProcessParameter.IsNeedT1CoregisterToFun=0; 
end
if ~isfield(AutoDataProcessParameter,'IsNeedReorientInteractivelyAfterCoreg')
    AutoDataProcessParameter.IsNeedReorientInteractivelyAfterCoreg=0; 
end
if ~isfield(AutoDataProcessParameter,'IsSegment')  %1: Segment; 2: New Segment
    AutoDataProcessParameter.IsSegment=0; 
end
if ~isfield(AutoDataProcessParameter,'IsDARTEL')
    AutoDataProcessParameter.IsDARTEL=0; 
end
if ~isfield(AutoDataProcessParameter,'IsNormalize')  %1: Normalization by using the EPI template directly; 2: Normalization by using the T1 image segment information (T1 images stored in 'DataProcessDir\T1Img' and initiated with 'co*'); 3: Normalized by DARTEL
    AutoDataProcessParameter.IsNormalize=0; 
end
if ~isfield(AutoDataProcessParameter,'IsDelFilesBeforeNormalize')
    AutoDataProcessParameter.IsDelFilesBeforeNormalize=0; 
end
if ~isfield(AutoDataProcessParameter,'IsSmooth')  %1: Smooth module in SPM; 2: Smooth by DARTEL
    AutoDataProcessParameter.IsSmooth=0; 
end
if ~isfield(AutoDataProcessParameter,'IsDetrend')
    AutoDataProcessParameter.IsDetrend=0; 
end
if ~isfield(AutoDataProcessParameter,'IsFilter')
    AutoDataProcessParameter.IsFilter=0; 
end
if ~isfield(AutoDataProcessParameter,'IsDelDetrendedFiles')
    AutoDataProcessParameter.IsDelDetrendedFiles=0; 
end
if isfield(AutoDataProcessParameter,'MaskFile')
    AutoDataProcessParameter.CalReHo.AMaskFilename=AutoDataProcessParameter.MaskFile;
    AutoDataProcessParameter.CalALFF.AMaskFilename=AutoDataProcessParameter.MaskFile;
    AutoDataProcessParameter.CalfALFF.AMaskFilename=AutoDataProcessParameter.MaskFile;
    AutoDataProcessParameter.CalFC.AMaskFilename=AutoDataProcessParameter.MaskFile;
end
if ~isfield(AutoDataProcessParameter,'IsCalReHo')
    AutoDataProcessParameter.IsCalReHo=0; 
end
if ~isfield(AutoDataProcessParameter,'IsCalALFF')
    AutoDataProcessParameter.IsCalALFF=0; 
end
if ~isfield(AutoDataProcessParameter,'IsCalfALFF')
    AutoDataProcessParameter.IsCalfALFF=0; 
end
if ~isfield(AutoDataProcessParameter,'IsCovremove')
    AutoDataProcessParameter.IsCovremove=0; 
end
if ~isfield(AutoDataProcessParameter,'IsCalFC')
    AutoDataProcessParameter.IsCalFC=0; 
end
if ~isfield(AutoDataProcessParameter,'CalFC')
    AutoDataProcessParameter.CalFC.ROIDef = {};
elseif ~isfield(AutoDataProcessParameter.CalFC,'ROIDef')
    AutoDataProcessParameter.CalFC.ROIDef = {};
end
if ~isfield(AutoDataProcessParameter,'IsExtractRESTdefinedROITC')
    AutoDataProcessParameter.IsExtractRESTdefinedROITC=0; 
end
if ~isfield(AutoDataProcessParameter,'IsDefineROIInteractively')
    AutoDataProcessParameter.IsDefineROIInteractively=0; 
end
if ~isfield(AutoDataProcessParameter,'IsExtractAALTC')
    AutoDataProcessParameter.IsExtractAALTC=0; 
end
if ~isfield(AutoDataProcessParameter,'IsWarpMasksIntoIndividualSpace')
    AutoDataProcessParameter.IsWarpMasksIntoIndividualSpace=0; 
end
if ~isfield(AutoDataProcessParameter,'IsExtractROITC')
    AutoDataProcessParameter.IsExtractROITC=0; 
end


AutoDataProcessParameter.SliceTiming.TR=AutoDataProcessParameter.TR;
AutoDataProcessParameter.SliceTiming.TA=AutoDataProcessParameter.SliceTiming.TR-(AutoDataProcessParameter.SliceTiming.TR/AutoDataProcessParameter.SliceTiming.SliceNumber);
AutoDataProcessParameter.Filter.ASamplePeriod=AutoDataProcessParameter.TR;
AutoDataProcessParameter.CalALFF.ASamplePeriod=AutoDataProcessParameter.TR;
AutoDataProcessParameter.CalfALFF.ASamplePeriod=AutoDataProcessParameter.TR;



% Multiple Sessions Processing 
% YAN Chao-Gan, 111215 added.
FunSessionPrefixSet={''}; %The first session doesn't need a prefix. From the second session, need a prefix such as 'S2_';
for iFunSession=2:AutoDataProcessParameter.FunctionalSessionNumber
    FunSessionPrefixSet=[FunSessionPrefixSet;{['S',num2str(iFunSession),'_']}];
end


%Convert Functional DICOM files to NIFTI images
if (AutoDataProcessParameter.IsNeedConvertFunDCM2IMG==1)
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'FunRaw']);
        for i=1:AutoDataProcessParameter.SubjectNum
            OutputDir=[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'FunImg',filesep,AutoDataProcessParameter.SubjectID{i}];
            mkdir(OutputDir);
            DirDCM=dir([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'FunRaw',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*']); %Revised by YAN Chao-Gan 100130. %DirDCM=dir([AutoDataProcessParameter.DataProcessDir,filesep,'FunRaw',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.*']);
            if strcmpi(DirDCM(3).name,'.DS_Store')  %110908 YAN Chao-Gan, for MAC OS compatablie
                StartIndex=4;
            else
                StartIndex=3;
            end
            InputFilename=[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'FunRaw',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirDCM(StartIndex).name];
            OldDirTemp=pwd; %Added by YAN Chao-Gan 100130.
            cd([ProgramPath,filesep,'dcm2nii']); %Revised by YAN Chao-Gan 100510. %cd([ProgramPath,filesep,'MRIcroN']);
            if ispc
                %eval(['!dcm2nii.exe -o ',OutputDir,' ',InputFilename]); %Revised by YAN Chao-Gan 100130. %eval(['!',ProgramPath,filesep,'MRIcroN',filesep,'dcm2nii.exe -o ',OutputDir,' ',InputFilename]);
                eval(['!dcm2nii.exe -b dcm2nii.ini -o ',OutputDir,' ',InputFilename]); %Revised by YAN Chao-Gan 100506.
            elseif ismac
                eval(['!./dcm2nii_mac -b ./dcm2nii_linux.ini -o ',OutputDir,' ',InputFilename]); %YAN Chao-Gan, 111115.
            else
                %101010 Changed to use MRIcroN's dcm2nii since its linux bug has been fixed.
                eval(['!chmod +x dcm2nii_linux']); %Revised by YAN Chao-Gan 100130. %eval(['!chmod +x ',ProgramPath,filesep,'MRIcroN',filesep,'dcm2nii_linux']);
                eval(['!./dcm2nii_linux -b ./dcm2nii_linux.ini -o ',OutputDir,' ',InputFilename]); %Revised by YAN Chao-Gan 100510. %eval(['!',ProgramPath,filesep,'MRIcroN',filesep,'dcm2nii_linux -a N -d Y -e Y -f N -g N -i Y -n N -p Y -s N -v Y -o ',OutputDir,' ',InputFilename]);
                %             %101010 Changed to use MRIcroN's dcm2nii since its linux bug has been fixed.
                %             %There is a bug in linux version of dcm2nii, it just convert the first time point into NIFTI images. So I turn to spm_dicom_convert. YAN Chao-Gan 090701
                %             FileList=[];
                %             for j=3:length(DirDCM)
                %                 FileList=[FileList;{[AutoDataProcessParameter.DataProcessDir,filesep,'FunRaw',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirDCM(j).name]}];
                %             end
                %             hdr = spm_dicom_headers(strvcat(FileList));
                %             cd(OutputDir);
                %             spm_dicom_convert(hdr,'all','flat','img');
                %             clear hdr; %Added by YAN Chao-Gan, 100420. To release the memory.
                %             cd([AutoDataProcessParameter.DataProcessDir,filesep,'FunRaw']);
            end
            cd(OldDirTemp); %Added by YAN Chao-Gan 100130.
            fprintf(['Converting Functional Images:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
    end
    AutoDataProcessParameter.StartingDirName='FunImg';   %Now start with FunImg directory. 101010
end


%Convert T1 DICOM files to NIFTI images
if (AutoDataProcessParameter.IsNeedConvertT1DCM2IMG==1)
    cd([AutoDataProcessParameter.DataProcessDir,filesep,'T1Raw']);
    for i=1:AutoDataProcessParameter.SubjectNum
        OutputDir=[AutoDataProcessParameter.DataProcessDir,filesep,'T1Img',filesep,AutoDataProcessParameter.SubjectID{i}];
        mkdir(OutputDir);
        DirDCM=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1Raw',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*']); %Revised by YAN Chao-Gan 100130. %DirDCM=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1Raw',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.*']);
        if strcmpi(DirDCM(3).name,'.DS_Store')  %110908 YAN Chao-Gan, for MAC OS compatablie
            StartIndex=4;
        else
            StartIndex=3;
        end
        InputFilename=[AutoDataProcessParameter.DataProcessDir,filesep,'T1Raw',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirDCM(StartIndex).name];
        OldDirTemp=pwd; %Added by YAN Chao-Gan 100130.
        cd([ProgramPath,filesep,'dcm2nii']); %Revised by YAN Chao-Gan 100510. %cd([ProgramPath,filesep,'MRIcroN']);
        if ispc
            %eval(['!dcm2nii.exe -o ',OutputDir,' ',InputFilename]); %Revised by YAN Chao-Gan 100130. %eval(['!',ProgramPath,filesep,'MRIcroN',filesep,'dcm2nii.exe -o ',OutputDir,' ',InputFilename]);
            %YAN Chao-Gan 100506
            eval(['!dcm2nii.exe -b dcm2nii.ini -o ',OutputDir,' ',InputFilename]);
        elseif ismac
            eval(['!./dcm2nii_mac -b ./dcm2nii_linux.ini -o ',OutputDir,' ',InputFilename]); %YAN Chao-Gan, 111115.
        else
            eval(['!chmod +x dcm2nii_linux']); %Revised by YAN Chao-Gan 100130. %eval(['!chmod +x ',ProgramPath,filesep,'MRIcroN',filesep,'dcm2nii_linux']);
            eval(['!./dcm2nii_linux -b ./dcm2nii_linux.ini -o ',OutputDir,' ',InputFilename]); %Revised by YAN Chao-Gan 100510. %eval(['!',ProgramPath,filesep,'MRIcroN',filesep,'dcm2nii_linux -a N -d Y -e Y -f N -g N -i Y -n N -p Y -s N -v Y -o ',OutputDir,' ',InputFilename]);
            %eval(['!dcm2nii_linux -a N -d Y -e Y -f N -g N -i Y -n N -p Y -s N -v Y -o ',OutputDir,' ',InputFilename]); %Revised by YAN Chao-Gan 100130. %eval(['!',ProgramPath,filesep,'MRIcroN',filesep,'dcm2nii_linux -a N -d Y -e Y -f N -g N -i Y -n N -p Y -s N -v Y -o ',OutputDir,' ',InputFilename]);
        end
        cd(OldDirTemp); %Added by YAN Chao-Gan 100130.
        fprintf(['Converting T1 Images:',AutoDataProcessParameter.SubjectID{i},' OK']);
    end
    fprintf('\n');
end

% Convert 4D functional .nii.gz or .nii into 3D .img/.hdr format
% YAN Chao-Gan, 111114.
if (AutoDataProcessParameter.IsNeedConvert4DFunInto3DImg==1)
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName]);
        for i=1:AutoDataProcessParameter.SubjectNum
            OutputDir=[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'Img',filesep,AutoDataProcessParameter.SubjectID{i}];
            theFileList = dir(fullfile([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}],'*.nii'));
            if isempty(theFileList)
                theFileList = dir(fullfile([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}],'*.nii.gz'));
            end
            ImgFileList ={};
            for x = 1:size(struct2cell(theFileList),2)
                ImgFileList=[ImgFileList; {[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,theFileList(x).name]}];
            end
            for x=1:length(ImgFileList)
                [Path, fileN, extn] = fileparts(ImgFileList{x});
                if strcmpi(extn,'.gz')
                    PO=[OutputDir,filesep,fileN(1:end-4),'.img'];
                else
                    PO=[OutputDir,filesep,fileN,'.img'];
                end
                mkdir(fileparts(PO));
                DPARSF_Nii2NiftiPairs(ImgFileList{x},PO);
            end
            fprintf(['Converting 4D functional .nii.gz or .nii into 3D .img/.hdr format:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
    end
    AutoDataProcessParameter.StartingDirName=[AutoDataProcessParameter.StartingDirName,'Img']; %Now StartingDirName is with new suffix 'Img'
end

% Uncompress T1 .nii.gz into T1Img
% YAN Chao-Gan, 111114.
if (AutoDataProcessParameter.IsNeedUnzipT1IntoT1Img==1)
    cd([AutoDataProcessParameter.DataProcessDir,filesep,'T1NiiGZ']);
    for i=1:AutoDataProcessParameter.SubjectNum
        OutputDir=[AutoDataProcessParameter.DataProcessDir,filesep,'T1Img',filesep,AutoDataProcessParameter.SubjectID{i}];
        mkdir(OutputDir);
        NiiGZFileList = dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1NiiGZ',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii.gz']);
        for iFile = 1:length(NiiGZFileList)
            gunzip([AutoDataProcessParameter.DataProcessDir,filesep,'T1NiiGZ',filesep,AutoDataProcessParameter.SubjectID{i},filesep,NiiGZFileList(iFile).name],OutputDir);
        end
        fprintf(['Uncompressing T1 .nii.gz into T1Img:',AutoDataProcessParameter.SubjectID{i},' OK']);
    end
    fprintf('\n');
end

%Reorient and Crop T1Img by using Chris Rorden's dcm2nii
% YAN Chao-Gan, 111121
if (AutoDataProcessParameter.IsNeedReorientCropT1Img==1)
    cd([AutoDataProcessParameter.DataProcessDir,filesep,'T1Img']);
    for i=1:AutoDataProcessParameter.SubjectNum
        OutputDir=[AutoDataProcessParameter.DataProcessDir,filesep,'T1Img',filesep,AutoDataProcessParameter.SubjectID{i}];
        DirImg=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1Img',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']); %Revised by YAN Chao-Gan 100130. %DirDCM=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1Raw',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.*']);
        if isempty(DirImg)
            DirImg=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1Img',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']); %Revised by YAN Chao-Gan 100130. %DirDCM=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1Raw',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.*']);
        end
        InputFilename=[AutoDataProcessParameter.DataProcessDir,filesep,'T1Img',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(1).name];
        OldDirTemp=pwd; %Added by YAN Chao-Gan 100130.
        cd([ProgramPath,filesep,'dcm2nii']); %Revised by YAN Chao-Gan 100510. %cd([ProgramPath,filesep,'MRIcroN']);
        if ispc
            eval(['!dcm2nii.exe -g N -m N -n Y -r Y -v N -x Y -o ',OutputDir,' ',InputFilename]);
        elseif ismac
            eval(['!./dcm2nii_mac -g N -m N -n Y -r Y -v N -x Y -o ',OutputDir,' ',InputFilename]); %YAN Chao-Gan, 111115.
        else
            eval(['!chmod +x dcm2nii_linux']); %Revised by YAN Chao-Gan 100130. %eval(['!chmod +x ',ProgramPath,filesep,'MRIcroN',filesep,'dcm2nii_linux']);
            eval(['!./dcm2nii_linux -g N -m N -n Y -r Y -v N -x Y -o ',OutputDir,' ',InputFilename]); %Revised by YAN Chao-Gan 100130. %eval(['!',ProgramPath,filesep,'MRIcroN',filesep,'dcm2nii_linux -a N -d Y -e Y -f N -g N -i Y -n N -p Y -s N -v Y -o ',OutputDir,' ',InputFilename]);
        end
        cd(OldDirTemp); %Added by YAN Chao-Gan 100130.
        fprintf(['Reorienting and Cropping Images:',AutoDataProcessParameter.SubjectID{i},' OK']);
    end
    fprintf('\n');
end


%****************************************************************Processing of fMRI BOLD images*****************
%Remove First Time Points
if (AutoDataProcessParameter.RemoveFirstTimePoints>0)
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName]);
        for i=1:AutoDataProcessParameter.SubjectNum
            cd(AutoDataProcessParameter.SubjectID{i});
            DirImg=dir('*.img');
            if ~isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
                if length(DirImg)~=AutoDataProcessParameter.TimePoints
                    Error=[Error;{['Error in Removing First ',num2str(AutoDataProcessParameter.RemoveFirstTimePoints),'Time Points: ',AutoDataProcessParameter.SubjectID{i}]}];
                end
                for j=1:AutoDataProcessParameter.RemoveFirstTimePoints
                    delete(DirImg(j).name);
                    delete([DirImg(j).name(1:end-4),'.hdr']);
                end
            else
                DirImg=dir('*.nii');
                if length(DirImg)~=AutoDataProcessParameter.TimePoints
                    Error=[Error;{['Error in Removing First ',num2str(AutoDataProcessParameter.RemoveFirstTimePoints),'Time Points: ',AutoDataProcessParameter.SubjectID{i}]}];
                end
                for j=1:AutoDataProcessParameter.RemoveFirstTimePoints
                    delete(DirImg(j).name);
                end
            end
            cd('..');
            fprintf(['Removing First ',num2str(AutoDataProcessParameter.RemoveFirstTimePoints),'Time Points:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
    end
    AutoDataProcessParameter.TimePoints=AutoDataProcessParameter.TimePoints-AutoDataProcessParameter.RemoveFirstTimePoints;
end
if ~isempty(Error)
    disp(Error);
    return;
end

%Slice Timing
if (AutoDataProcessParameter.IsSliceTiming==1)
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        load([ProgramPath,filesep,'Jobmats',filesep,'SliceTiming.mat']);
        cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName]);
        for i=1:AutoDataProcessParameter.SubjectNum
            cd(AutoDataProcessParameter.SubjectID{i});
            DirImg=dir('*.img');
            if isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
                DirImg=dir('*.nii');
            end
            if length(DirImg)~=AutoDataProcessParameter.TimePoints
                Error=[Error;{['Error in SliceTiming: ',AutoDataProcessParameter.SubjectID{i}]}];
            end
            FileList=[];
            for j=1:length(DirImg)
                FileList=[FileList;{[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(j).name,',1']}];
            end
            jobs{1,1}.temporal{1,1}.st.scans{i}=FileList;
            cd('..');
            fprintf(['Slice Timing Setup:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
        jobs{1,1}.temporal{1,1}.st.nslices=AutoDataProcessParameter.SliceTiming.SliceNumber;
        jobs{1,1}.temporal{1,1}.st.tr=AutoDataProcessParameter.SliceTiming.TR;
        jobs{1,1}.temporal{1,1}.st.ta=AutoDataProcessParameter.SliceTiming.TA;
        jobs{1,1}.temporal{1,1}.st.so=AutoDataProcessParameter.SliceTiming.SliceOrder;
        jobs{1,1}.temporal{1,1}.st.refslice=AutoDataProcessParameter.SliceTiming.ReferenceSlice;
        if SPMversion==5
            spm_jobman('run',jobs);
        elseif SPMversion==8  %YAN Chao-Gan, 090925. SPM8 compatible.
            jobs = spm_jobman('spm5tospm8',{jobs});
            spm_jobman('run',jobs{1});
        else
            uiwait(msgbox('The current SPM version is not supported by DPARSF. Please install SPM5 or SPM8 first.','Invalid SPM Version.'));
            return
        end
        
        %Copy the Slice Timing Corrected files to DataProcessDir\{AutoDataProcessParameter.StartingDirName}+A
        cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName]);
        for i=1:AutoDataProcessParameter.SubjectNum
            cd(AutoDataProcessParameter.SubjectID{i});
            mkdir(['..',filesep,'..',filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'A',filesep,AutoDataProcessParameter.SubjectID{i}])
            movefile('a*',['..',filesep,'..',filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'A',filesep,AutoDataProcessParameter.SubjectID{i}])
            cd('..');
            fprintf(['Moving Slice Timing Corrected Files:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
        
    end
    AutoDataProcessParameter.StartingDirName=[AutoDataProcessParameter.StartingDirName,'A']; %Now StartingDirName is with new suffix 'A'
end
if ~isempty(Error)
    disp(Error);
    return;
end

%Realign
if (AutoDataProcessParameter.IsRealign==1)
    load([ProgramPath,filesep,'Jobmats',filesep,'Realign.mat']);
    for i=1:AutoDataProcessParameter.SubjectNum
        if i~=1
            jobs{1,1}.spatial{1,1}.realign=[jobs{1,1}.spatial{1,1}.realign,{jobs{1,1}.spatial{1,1}.realign{1,1}}];
        end
        for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
            cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}]);
            DirImg=dir('*.img');
            if isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
                DirImg=dir('*.nii');
            end
            if length(DirImg)~=AutoDataProcessParameter.TimePoints
                Error=[Error;{['Error in Realign: ',AutoDataProcessParameter.SubjectID{i}]}];
            end
            FileList=[];
            for j=1:length(DirImg)
                FileList=[FileList;{[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(j).name,',1']}];
            end
            jobs{1,1}.spatial{1,1}.realign{1,i}.estwrite.data{1,iFunSession}=FileList;
            cd('..');
            fprintf(['Realign Setup:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
    end
    fprintf('\n');
    if SPMversion==5
        spm_jobman('run',jobs);
    elseif SPMversion==8  %YAN Chao-Gan, 090925. SPM8 compatible.
        jobs = spm_jobman('spm5tospm8',{jobs});
        spm_jobman('run',jobs{1});
    else
        uiwait(msgbox('The current SPM version is not supported by DPARSF. Please install SPM5 or SPM8 first.','Invalid SPM Version.'));
        return
    end

    %Copy the Realign Parameters
    mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter']);
    if ~isempty(dir('*.ps'))
        copyfile('*.ps',[AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter']);
    end
    for i=1:AutoDataProcessParameter.SubjectNum
        cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{1},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}]);
        mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i}]);
        copyfile('mean*',[AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i}]);
        copyfile('rp*.txt',[AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i}]);
        for iFunSession=2:AutoDataProcessParameter.FunctionalSessionNumber
            cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}]);
            DirRP=dir('rp*.txt');
            [PathTemp, fileN, extn] = fileparts(DirRP.name);
            copyfile([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirRP.name],[AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,FunSessionPrefixSet{iFunSession},fileN, extn]);
        end
    end

    %Copy the Head Motion Corrected files to DataProcessDir\{AutoDataProcessParameter.StartingDirName}+R
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName]);
        for i=1:AutoDataProcessParameter.SubjectNum
            cd(AutoDataProcessParameter.SubjectID{i});
            mkdir(['..',filesep,'..',filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'R',filesep,AutoDataProcessParameter.SubjectID{i}])
            DirImg=dir('*.img');
            if ~isempty(DirImg)  %YAN Chao-Gan, 111114
                movefile('r*.img',['..',filesep,'..',filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'R',filesep,AutoDataProcessParameter.SubjectID{i}])
                movefile('r*.hdr',['..',filesep,'..',filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'R',filesep,AutoDataProcessParameter.SubjectID{i}])
            else
                movefile('r*.nii',['..',filesep,'..',filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'R',filesep,AutoDataProcessParameter.SubjectID{i}])
            end
            cd('..');
            fprintf(['Moving Head Motion Corrected Files:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
    end
    fprintf('\n');
    AutoDataProcessParameter.StartingDirName=[AutoDataProcessParameter.StartingDirName,'R']; %Now StartingDirName is with new suffix 'R'
    
    %Check Head Motion
    cd([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter']);
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        HeadMotion=[];
        for i=1:AutoDataProcessParameter.SubjectNum
            cd(AutoDataProcessParameter.SubjectID{i});
            rpname=dir([FunSessionPrefixSet{iFunSession},'rp*']);
            b=load(rpname.name);
            c=max(abs(b));
            c(4:6)=c(4:6)*180/pi;
            HeadMotion=[HeadMotion;c];
            cd('..');
        end
        save([FunSessionPrefixSet{iFunSession},'HeadMotion.mat'],'HeadMotion');
        
        ExcludeSub_Text=[];
        for ExcludingCriteria=3:-0.5:0.5
            BigHeadMotion=find(HeadMotion>ExcludingCriteria);
            if ~isempty(BigHeadMotion)
                [II JJ]=ind2sub([AutoDataProcessParameter.SubjectNum,6],BigHeadMotion);
                ExcludeSub=unique(II);
                ExcludeSub_ID=AutoDataProcessParameter.SubjectID(ExcludeSub);
                TempText='';
                for iExcludeSub=1:length(ExcludeSub_ID)
                    TempText=sprintf('%s%s\n',TempText,ExcludeSub_ID{iExcludeSub});
                end
            else
                TempText='None';
            end
            ExcludeSub_Text=sprintf('%s\nExcluding Criteria: %2.1fmm and %2.1f degree\n%s\n\n\n',ExcludeSub_Text,ExcludingCriteria,ExcludingCriteria,TempText);
        end
        fid = fopen([FunSessionPrefixSet{iFunSession},'ExcludeSubjects.txt'],'at+');
        fprintf(fid,'%s',ExcludeSub_Text);
        fclose(fid);
    end
    
end
if ~isempty(Error)
    disp(Error);
    return;
end

%Reorient T1 Image Interactively
if (AutoDataProcessParameter.IsNeedReorientT1ImgInteractively==1)
    cd([AutoDataProcessParameter.DataProcessDir,filesep,'T1Img',filesep,AutoDataProcessParameter.SubjectID{1}]);
    DirCo=dir('c*.img');
    if isempty(DirCo)
        DirCo=dir('c*.nii');  %YAN Chao-Gan, 111114. Also support .nii files.
    end
    if isempty(DirCo)
        DirImg=dir('*.img');
        if isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
            DirImg=dir('*.nii');
        end
        if length(DirImg)==1
            button = questdlg(['No co* T1 image (T1 image which is reoriented to the nearest orthogonal direction to ''canonical space'' and removed excess air surrounding the individual as well as parts of the neck below the cerebellum) is found. Do you want to use the T1 image without co? Such as: ',DirImg(1).name,'?'],'No co* T1 image is found','Yes','No','Yes');
            if strcmpi(button,'Yes')
                UseNoCoT1Image=1;
            else
                return;
            end
        elseif length(DirImg)==0
            errordlg(['No T1 image has been found.'],'No T1 image has been found');
            return;
        else
            errordlg(['No co* T1 image (T1 image which is reoriented to the nearest orthogonal direction to ''canonical space'' and removed excess air surrounding the individual as well as parts of the neck below the cerebellum) is found. And there are too many T1 images detected in T1Img directory. Please determine which T1 image you want to use and delete the others from the T1Img directory, then re-run the analysis.'],'No co* T1 image is found');
            return;
        end
    else
        UseNoCoT1Image=0;
    end
    cd('..');

    if ~(7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'ReorientMats'],'dir'))
        mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'ReorientMats']);
    end
    %Reorient
    for i=1:AutoDataProcessParameter.SubjectNum
        if UseNoCoT1Image==0
            DirT1Img=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1Img',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'c*.img']);
            if isempty(DirT1Img)
                DirT1Img=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1Img',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'c*.nii']);
            end
        else
            DirT1Img=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1Img',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
            if isempty(DirT1Img)
                DirT1Img=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1Img',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
            end
        end
        FileList=[{[AutoDataProcessParameter.DataProcessDir,filesep,'T1Img',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirT1Img(1).name,',1']}];
        fprintf('Reorienting T1 Image Interactively for %s: \n',AutoDataProcessParameter.SubjectID{i});
        global DPARSFA_spm_image_Parameters
        DPARSFA_spm_image_Parameters.ReorientFileList=FileList;
        uiwait(DPARSFA_spm_image('init',[AutoDataProcessParameter.DataProcessDir,filesep,'T1Img',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirT1Img(1).name]));
        mat=DPARSFA_spm_image_Parameters.ReorientMat;
        save([AutoDataProcessParameter.DataProcessDir,filesep,'ReorientMats',filesep,AutoDataProcessParameter.SubjectID{i},'_ReorientT1ImgMat.mat'],'mat')
        clear global DPARSFA_spm_image_Parameters
        fprintf('Reorienting T1 Image Interactively for %s: OK\n',AutoDataProcessParameter.SubjectID{i});
    end
end
if ~isempty(Error)
    disp(Error);
    return;
end

%Reorient Functional Images Interactively
if (AutoDataProcessParameter.IsNeedReorientFunImgInteractively==1)
    % Check if mean* image generated in Head Motion Correction exist. Added by YAN Chao-Gan 101010.
    if 7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{1}],'dir')
        DirMean=dir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{1},filesep,'mean*.img']);
        if isempty(DirMean)  %YAN Chao-Gan, 111114. Also support .nii files.
            DirMean=dir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{1},filesep,'mean*.nii']);
        end
    else
        DirMean=[];
    end
    if isempty(DirMean)
        % Generate mean image. ONLY FOR situation with ONE SESSION.
        cd([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName]);
        for i=1:AutoDataProcessParameter.SubjectNum
            fprintf('\nCalculate mean functional brain (%s) for "%s" since there is no mean* image generated in Head Motion Correction exist.\n',AutoDataProcessParameter.StartingDirName, AutoDataProcessParameter.SubjectID{i});
            cd(AutoDataProcessParameter.SubjectID{i});
            DirImg=dir('*.img');
            if isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
                DirImg=dir('*.nii');
            end
            [Data, Header] = rest_ReadNiftiImage(DirImg(1).name);
            AllVolume =repmat(Data, [1,1,1, length(DirImg)]);
            for j=2:length(DirImg)
                [Data, Header] = rest_ReadNiftiImage(DirImg(j).name);
                AllVolume(:,:,:,j) = Data;
                if ~mod(j,5)
                    fprintf('.');
                end
            end
            AllVolume=mean(AllVolume,4);
            mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i}]);
            Header.pinfo = [1;0;0];
            Header.dt    =[16,0];
            rest_WriteNiftiImage(AllVolume,Header,[AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'mean',AutoDataProcessParameter.SubjectID{i},'img']);
            fprintf('\nMean functional brain (%s) for "%s" saved as: %s\n',AutoDataProcessParameter.StartingDirName, AutoDataProcessParameter.SubjectID{i}, [AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'mean',AutoDataProcessParameter.SubjectID{i},'img']);
            cd('..');
        end
    end

    if ~(7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'ReorientMats'],'dir'))
        mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'ReorientMats']);
    end
    %Reorient
    cd([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName]);
    for i=1:AutoDataProcessParameter.SubjectNum
        FileList=[];
        for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
            cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}]);
            DirImg=dir('*.img');
            if isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
                DirImg=dir('*.nii');
            end
            if length(DirImg)~=AutoDataProcessParameter.TimePoints
                Error=[Error;{['Error in Reorient: ',AutoDataProcessParameter.SubjectID{i}]}];
            end
            for j=1:length(DirImg)
                FileList=[FileList;{[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(j).name,',1']}];
            end
        end

        % Find the mean* functional image.
        if 7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i}],'dir')
            DirMean=dir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'mean*.img']);
            if isempty(DirMean)  %YAN Chao-Gan, 111114. Also support .nii files.
                DirMean=dir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'mean*.nii']);
            end
            if ~isempty(DirMean)
                FileList=[FileList;{[AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirMean(1).name,',1']}];
            end
        end

        fprintf('Reorienting Functional Images Interactively for %s: \n',AutoDataProcessParameter.SubjectID{i});
        global DPARSFA_spm_image_Parameters
        DPARSFA_spm_image_Parameters.ReorientFileList=FileList;
        uiwait(DPARSFA_spm_image('init',[AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirMean(1).name,',1']));
        mat=DPARSFA_spm_image_Parameters.ReorientMat;
        save([AutoDataProcessParameter.DataProcessDir,filesep,'ReorientMats',filesep,AutoDataProcessParameter.SubjectID{i},'_ReorientFunImgMat.mat'],'mat')
        clear global DPARSFA_spm_image_Parameters
        fprintf('Reorienting Functional Images Interactively for %s: OK\n',AutoDataProcessParameter.SubjectID{i});
    end
end
if ~isempty(Error)
    disp(Error);
    return;
end

%Coregister T1 Image to Functional space
if (AutoDataProcessParameter.IsNeedT1CoregisterToFun==1)
    %Backup the T1 images to T1ImgCoreg
    cd([AutoDataProcessParameter.DataProcessDir,filesep,'T1Img']);
    % Check if co* image exist. Added by YAN Chao-Gan 100510.
    cd(AutoDataProcessParameter.SubjectID{1});
    DirCo=dir('c*.img');
    if isempty(DirCo)
        DirCo=dir('c*.nii');  %YAN Chao-Gan, 111114. Also support .nii files.
    end
    if isempty(DirCo)
        DirImg=dir('*.img');
        if isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
            DirImg=dir('*.nii');
        end
        if length(DirImg)==1
            button = questdlg(['No co* T1 image (T1 image which is reoriented to the nearest orthogonal direction to ''canonical space'' and removed excess air surrounding the individual as well as parts of the neck below the cerebellum) is found. Do you want to use the T1 image without co? Such as: ',DirImg(1).name,'?'],'No co* T1 image is found','Yes','No','Yes');
            if strcmpi(button,'Yes')
                UseNoCoT1Image=1;
            else
                return;
            end
        elseif length(DirImg)==0
            errordlg(['No T1 image has been found.'],'No T1 image has been found');
            return;
        else
            errordlg(['No co* T1 image (T1 image which is reoriented to the nearest orthogonal direction to ''canonical space'' and removed excess air surrounding the individual as well as parts of the neck below the cerebellum) is found. And there are too many T1 images detected in T1Img directory. Please determine which T1 image you want to use and delete the others from the T1Img directory, then re-run the analysis.'],'No co* T1 image is found');
            return;
        end
    else
        UseNoCoT1Image=0;
    end
    cd('..');
    for i=1:AutoDataProcessParameter.SubjectNum
        cd(AutoDataProcessParameter.SubjectID{i});
        mkdir(['..',filesep,'..',filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i}])
        % Check in co* image exist. Added by YAN Chao-Gan 100510.
        if UseNoCoT1Image==0
            copyfile('c*',['..',filesep,'..',filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i}])
        else
            DirImg=dir('*.img');
            if ~isempty(DirImg)  %YAN Chao-Gan, 111114
                copyfile('*.hdr',['..',filesep,'..',filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i}])
                copyfile('*.img',['..',filesep,'..',filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i}])
            else
                copyfile('*.nii',['..',filesep,'..',filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i}])
            end
        end
        cd('..');
        fprintf(['Copying T1 image Files:',AutoDataProcessParameter.SubjectID{i},' OK']);
    end
    fprintf('\n');

    % Check if mean* image generated in Head Motion Correction exist. Added by YAN Chao-Gan 101010.
    if 7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{1}],'dir')
        DirMean=dir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{1},filesep,'mean*.img']);
        if isempty(DirMean)  %YAN Chao-Gan, 111114. Also support .nii files.
            DirMean=dir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{1},filesep,'mean*.nii']);
        end
    else
        DirMean=[];
    end
    if isempty(DirMean)
        cd([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName]);
        for i=1:AutoDataProcessParameter.SubjectNum
            fprintf('\nCalculate mean functional brain (%s) for "%s" since there is no mean* image generated in Head Motion Correction exist.\n',AutoDataProcessParameter.StartingDirName, AutoDataProcessParameter.SubjectID{i});
            cd(AutoDataProcessParameter.SubjectID{i});
            DirImg=dir('*.img');
            if isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
                DirImg=dir('*.nii');
            end
            [Data, Header] = rest_ReadNiftiImage(DirImg(1).name);
            AllVolume =repmat(Data, [1,1,1, length(DirImg)]);
            for j=2:length(DirImg)
                [Data, Header] = rest_ReadNiftiImage(DirImg(j).name);
                AllVolume(:,:,:,j) = Data;
                if ~mod(j,5)
                    fprintf('.');
                end
            end
            AllVolume=mean(AllVolume,4);
            mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i}]);
            Header.pinfo = [1;0;0];
            Header.dt    =[16,0];
            rest_WriteNiftiImage(AllVolume,Header,[AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'mean',AutoDataProcessParameter.SubjectID{i},'img']);
            fprintf('\nMean functional brain (%s) for "%s" saved as: %s\n',AutoDataProcessParameter.StartingDirName, AutoDataProcessParameter.SubjectID{i}, [AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'mean',AutoDataProcessParameter.SubjectID{i},'img']);
            cd('..');
        end
    end

    load([ProgramPath,filesep,'Jobmats',filesep,'Coregister.mat']);
    for i=1:AutoDataProcessParameter.SubjectNum
        RefDir=dir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'mean*.img']);
        if isempty(RefDir)  %YAN Chao-Gan, 111114. Also support .nii files.
            RefDir=dir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'mean*.nii']);
        end
        RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefDir(1).name,',1'];
        SourceDir=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
        if isempty(SourceDir)  %YAN Chao-Gan, 111114. Also support .nii files.
           SourceDir=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']); 
        end
        SourceFile=[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i},filesep,SourceDir(1).name];
        if i~=1
            jobs=[jobs,{jobs{1,1}}];
        end
        jobs{1,i}.spatial{1,1}.coreg{1,1}.estimate.ref={RefFile};
        jobs{1,i}.spatial{1,1}.coreg{1,1}.estimate.source={SourceFile};
        fprintf(['Coregister Setup:',AutoDataProcessParameter.SubjectID{i},' OK']);
    end
    fprintf('\n');
    if SPMversion==5
        spm_jobman('run',jobs);
    elseif SPMversion==8  %YAN Chao-Gan, 090925. SPM8 compatible.
        jobs = spm_jobman('spm5tospm8',{jobs});
        spm_jobman('run',jobs{1});
    else
        uiwait(msgbox('The current SPM version is not supported by DPARSF. Please install SPM5 or SPM8 first.','Invalid SPM Version.'));
        return
    end
end

%Reorient Interactively After Coregistration for better orientation in Segmentation
if (AutoDataProcessParameter.IsNeedReorientInteractivelyAfterCoreg==1)
    if 7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{1}],'dir')
        DirT1ImgCoreg=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{1},filesep,'*.img']);
        if isempty(DirT1ImgCoreg)  %YAN Chao-Gan, 111114. Also support .nii files.
            DirT1ImgCoreg=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{1},filesep,'*.nii']);
        end
    else
        DirT1ImgCoreg=[];
    end
    if isempty(DirT1ImgCoreg)
        %Backup the T1 images to T1ImgCoreg
        cd([AutoDataProcessParameter.DataProcessDir,filesep,'T1Img']);
        % Check if co* image exist. Added by YAN Chao-Gan 100510.
        cd(AutoDataProcessParameter.SubjectID{1});
        DirCo=dir('c*.img');
        if isempty(DirCo)
            DirCo=dir('c*.nii');  %YAN Chao-Gan, 111114. Also support .nii files.
        end
        if isempty(DirCo)
            DirImg=dir('*.img');
            if isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
                DirImg=dir('*.nii');
            end
            if length(DirImg)==1
                button = questdlg(['No co* T1 image (T1 image which is reoriented to the nearest orthogonal direction to ''canonical space'' and removed excess air surrounding the individual as well as parts of the neck below the cerebellum) is found. Do you want to use the T1 image without co? Such as: ',DirImg(1).name,'?'],'No co* T1 image is found','Yes','No','Yes');
                if strcmpi(button,'Yes')
                    UseNoCoT1Image=1;
                else
                    return;
                end
            elseif length(DirImg)==0
                errordlg(['No T1 image has been found.'],'No T1 image has been found');
                return;
            else
                errordlg(['No co* T1 image (T1 image which is reoriented to the nearest orthogonal direction to ''canonical space'' and removed excess air surrounding the individual as well as parts of the neck below the cerebellum) is found. And there are too many T1 images detected in T1Img directory. Please determine which T1 image you want to use and delete the others from the T1Img directory, then re-run the analysis.'],'No co* T1 image is found');
                return;
            end
        else
            UseNoCoT1Image=0;
        end
        cd('..');
        for i=1:AutoDataProcessParameter.SubjectNum
            cd(AutoDataProcessParameter.SubjectID{i});
            mkdir(['..',filesep,'..',filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i}])
            % Check in co* image exist. Added by YAN Chao-Gan 100510.
            if UseNoCoT1Image==0
                copyfile('c*',['..',filesep,'..',filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i}])
            else
                DirImg=dir('*.img');
                if ~isempty(DirImg)  %YAN Chao-Gan, 111114
                    copyfile('*.hdr',['..',filesep,'..',filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i}])
                    copyfile('*.img',['..',filesep,'..',filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i}])
                else
                    copyfile('*.nii',['..',filesep,'..',filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i}])
                end
            end
            cd('..');
            fprintf(['Copying T1 image Files from "T1Img":',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
    end

    %Reorient
    cd([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName]);
    for i=1:AutoDataProcessParameter.SubjectNum
        FileList=[];
        for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
            cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}]);
            DirImg=dir('*.img');
            if isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
                DirImg=dir('*.nii');
            end
            if length(DirImg)~=AutoDataProcessParameter.TimePoints
                Error=[Error;{['Error in Reorient: ',AutoDataProcessParameter.SubjectID{i}]}];
            end
            for j=1:length(DirImg)
                FileList=[FileList;{[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(j).name,',1']}];
            end
        end

        DirT1ImgCoreg=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
        if isempty(DirT1ImgCoreg)  %YAN Chao-Gan, 111114. Also support .nii files.
            DirT1ImgCoreg=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
        end
        FileList=[FileList;{[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirT1ImgCoreg(1).name,',1']}];

        % if the mean* functional image exist, then also reorient it.
        if 7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i}],'dir')
            DirMean=dir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'mean*.img']);
            if isempty(DirMean)  %YAN Chao-Gan, 111114. Also support .nii files.
                DirMean=dir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'mean*.nii']);
            end
            if ~isempty(DirMean)
                FileList=[FileList;{[AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirMean(1).name,',1']}];
            end
        end

        fprintf('Reorienting Interactively After Coregistration for %s: \n',AutoDataProcessParameter.SubjectID{i});
        global DPARSFA_spm_image_Parameters
        DPARSFA_spm_image_Parameters.ReorientFileList=FileList;
        uiwait(DPARSFA_spm_image('init',[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirT1ImgCoreg(1).name]));
        mat=DPARSFA_spm_image_Parameters.ReorientMat;
        save([AutoDataProcessParameter.DataProcessDir,filesep,'ReorientMats',filesep,AutoDataProcessParameter.SubjectID{i},'_ReorientT1FunAfterCoregMat.mat'],'mat')
        clear global DPARSFA_spm_image_Parameters
        fprintf('Reorienting Interactively After Coregistration for %s: OK\n',AutoDataProcessParameter.SubjectID{i});
        cd('..');
    end
end
if ~isempty(Error)
    disp(Error);
    return;
end


% Segmentation
if (AutoDataProcessParameter.IsSegment>=1)
    if AutoDataProcessParameter.IsSegment==1
        T1ImgSegmentDirectoryName = 'T1ImgSegment';
    elseif AutoDataProcessParameter.IsSegment==2
        T1ImgSegmentDirectoryName = 'T1ImgNewSegment';
    end
    if 7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{1}],'dir')
        DirT1ImgCoreg=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{1},filesep,'*.img']);
        if isempty(DirT1ImgCoreg)  %YAN Chao-Gan, 111114. Also support .nii files.
            DirT1ImgCoreg=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{1},filesep,'*.nii']);
        end
    else
        DirT1ImgCoreg=[];
    end
    if isempty(DirT1ImgCoreg)
        %Backup the T1 images to T1ImgSegment
        cd([AutoDataProcessParameter.DataProcessDir,filesep,'T1Img']);
        % Check if co* image exist. Added by YAN Chao-Gan 100510.
        cd(AutoDataProcessParameter.SubjectID{1});
        DirCo=dir('c*.img');
        if isempty(DirCo)
            DirCo=dir('c*.nii');  %YAN Chao-Gan, 111114. Also support .nii files.
        end
        if isempty(DirCo)
            DirImg=dir('*.img');
            if isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
                DirImg=dir('*.nii');
            end
            if length(DirImg)==1
                button = questdlg(['No co* T1 image (T1 image which is reoriented to the nearest orthogonal direction to ''canonical space'' and removed excess air surrounding the individual as well as parts of the neck below the cerebellum) is found. Do you want to use the T1 image without co? Such as: ',DirImg(1).name,'?'],'No co* T1 image is found','Yes','No','Yes');
                if strcmpi(button,'Yes')
                    UseNoCoT1Image=1;
                else
                    return;
                end
            elseif length(DirImg)==0
                errordlg(['No T1 image has been found.'],'No T1 image has been found');
                return;
            else
                errordlg(['No co* T1 image (T1 image which is reoriented to the nearest orthogonal direction to ''canonical space'' and removed excess air surrounding the individual as well as parts of the neck below the cerebellum) is found. And there are too many T1 images detected in T1Img directory. Please determine which T1 image you want to use and delete the others from the T1Img directory, then re-run the analysis.'],'No co* T1 image is found');
                return;
            end
        else
            UseNoCoT1Image=0;
        end
        cd([AutoDataProcessParameter.DataProcessDir,filesep,'T1Img']);
        for i=1:AutoDataProcessParameter.SubjectNum
            cd(AutoDataProcessParameter.SubjectID{i});
            mkdir(['..',filesep,'..',filesep,T1ImgSegmentDirectoryName,filesep,AutoDataProcessParameter.SubjectID{i}])
            % Check in co* image exist. Added by YAN Chao-Gan 100510.
            if UseNoCoT1Image==0
                copyfile('c*',['..',filesep,'..',filesep,T1ImgSegmentDirectoryName,filesep,AutoDataProcessParameter.SubjectID{i}])
            else
                DirImg=dir('*.img');
                if ~isempty(DirImg)  %YAN Chao-Gan, 111114
                    copyfile('*.hdr',['..',filesep,'..',filesep,T1ImgSegmentDirectoryName,filesep,AutoDataProcessParameter.SubjectID{i}])
                    copyfile('*.img',['..',filesep,'..',filesep,T1ImgSegmentDirectoryName,filesep,AutoDataProcessParameter.SubjectID{i}])
                else
                    copyfile('*.nii',['..',filesep,'..',filesep,T1ImgSegmentDirectoryName,filesep,AutoDataProcessParameter.SubjectID{i}])
                end
            end
            cd('..');
            fprintf(['Copying T1 image Files from "T1Img":',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
        
    else  % T1ImgCoreg exists
        cd([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgCoreg']);
        for i=1:AutoDataProcessParameter.SubjectNum
            cd(AutoDataProcessParameter.SubjectID{i});
            mkdir([AutoDataProcessParameter.DataProcessDir,filesep,T1ImgSegmentDirectoryName,filesep,AutoDataProcessParameter.SubjectID{i}])
            DirImg=dir('*.img');
            if ~isempty(DirImg)  %YAN Chao-Gan, 111114
                copyfile('*.hdr',[AutoDataProcessParameter.DataProcessDir,filesep,T1ImgSegmentDirectoryName,filesep,AutoDataProcessParameter.SubjectID{i}])
                copyfile('*.img',[AutoDataProcessParameter.DataProcessDir,filesep,T1ImgSegmentDirectoryName,filesep,AutoDataProcessParameter.SubjectID{i}])
            else
                copyfile('*.nii',[AutoDataProcessParameter.DataProcessDir,filesep,T1ImgSegmentDirectoryName,filesep,AutoDataProcessParameter.SubjectID{i}])
            end
            cd('..');
            fprintf(['Copying coregistered T1 image Files from "T1ImgCoreg":',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
    end

    if AutoDataProcessParameter.IsSegment==1  %Segment
        load([ProgramPath,filesep,'Jobmats',filesep,'Segment.mat']);
        cd([AutoDataProcessParameter.DataProcessDir,filesep,T1ImgSegmentDirectoryName]);
        for i=1:AutoDataProcessParameter.SubjectNum
            SourceDir=dir([AutoDataProcessParameter.DataProcessDir,filesep,T1ImgSegmentDirectoryName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
            if isempty(SourceDir)  %YAN Chao-Gan, 111114. Also support .nii files.
                SourceDir=dir([AutoDataProcessParameter.DataProcessDir,filesep,T1ImgSegmentDirectoryName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
            end
            SourceFile=[AutoDataProcessParameter.DataProcessDir,filesep,T1ImgSegmentDirectoryName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,SourceDir(1).name];
            if i~=1
                jobs=[jobs,{jobs{1,1}}];
            end
            [SPMPath, fileN, extn] = fileparts(which('spm.m'));
            jobs{1,i}.spatial{1,1}.preproc.opts.tpm={[SPMPath,filesep,'tpm',filesep,'grey.nii'];[SPMPath,filesep,'tpm',filesep,'white.nii'];[SPMPath,filesep,'tpm',filesep,'csf.nii']};
            jobs{1,i}.spatial{1,1}.preproc.data={SourceFile};
            if strcmpi(AutoDataProcessParameter.Segment.AffineRegularisationInSegmentation,'mni')   %Added by YAN Chao-Gan 091110. Use different Affine Regularisation in Segmentation: East Asian brains (eastern) or European brains (mni).
                jobs{1,i}.spatial{1,1}.preproc.opts.regtype='mni';
            else
                jobs{1,i}.spatial{1,1}.preproc.opts.regtype='eastern';
            end
            fprintf(['Segment Setup:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
        if SPMversion==5
            spm_jobman('run',jobs);
        elseif SPMversion==8  %YAN Chao-Gan, 090925. SPM8 compatible.
            jobs = spm_jobman('spm5tospm8',{jobs});
            spm_jobman('run',jobs{1});
        else
            uiwait(msgbox('The current SPM version is not supported by DPARSF. Please install SPM5 or SPM8 first.','Invalid SPM Version.'));
            return
        end
    elseif AutoDataProcessParameter.IsSegment==2  %New Segment in SPM8 %YAN Chao-Gan, 111111.
        load([ProgramPath,filesep,'Jobmats',filesep,'NewSegment.mat']);
        [SPMPath, fileN, extn] = fileparts(which('spm.m'));
        for T1ImgSegmentDirectoryNameue=1:6
            matlabbatch{1,1}.spm.tools.preproc8.tissue(1,T1ImgSegmentDirectoryNameue).tpm{1,1}=[SPMPath,filesep,'toolbox',filesep,'Seg',filesep,'TPM.nii',',',num2str(T1ImgSegmentDirectoryNameue)];
            matlabbatch{1,1}.spm.tools.preproc8.tissue(1,T1ImgSegmentDirectoryNameue).warped = [0 0]; % Do not need warped results. Warp by DARTEL
        end
        if strcmpi(AutoDataProcessParameter.Segment.AffineRegularisationInSegmentation,'mni')   %Added by YAN Chao-Gan 091110. Use different Affine Regularisation in Segmentation: East Asian brains (eastern) or European brains (mni).
            matlabbatch{1,1}.spm.tools.preproc8.warp.affreg='mni';
        else
            matlabbatch{1,1}.spm.tools.preproc8.warp.affreg='eastern';
        end
        
        T1SourceFileSet=[]; % Save to use in the step of DARTEL normalize to MNI
        cd([AutoDataProcessParameter.DataProcessDir,filesep,T1ImgSegmentDirectoryName]);
        for i=1:AutoDataProcessParameter.SubjectNum
            SourceDir=dir([AutoDataProcessParameter.DataProcessDir,filesep,T1ImgSegmentDirectoryName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
            if isempty(SourceDir)  %YAN Chao-Gan, 111114. Also support .nii files.
                SourceDir=dir([AutoDataProcessParameter.DataProcessDir,filesep,T1ImgSegmentDirectoryName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
            end
            SourceFile=[AutoDataProcessParameter.DataProcessDir,filesep,T1ImgSegmentDirectoryName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,SourceDir(1).name];
            if i~=1
                matlabbatch=[matlabbatch,{matlabbatch{1,1}}];
            end
            matlabbatch{1,i}.spm.tools.preproc8.channel.vols={SourceFile};
            T1SourceFileSet=[T1SourceFileSet;{SourceFile}];
            fprintf(['Segment Setup:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
        spm_jobman('run',matlabbatch);
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%DARTEL and Normalize VBM results. %YAN Chao-Gan, 111111.
if (AutoDataProcessParameter.IsDARTEL==1)
    %DARTEL: Create Template
    load([ProgramPath,filesep,'Jobmats',filesep,'Dartel_CreateTemplate.mat']);
    %Look for rc1* and rc2* images.
    cd([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgNewSegment']);
    rc1FileList=[];
    rc2FileList=[];
    for i=1:AutoDataProcessParameter.SubjectNum
        cd(AutoDataProcessParameter.SubjectID{i});
        DirImg=dir('rc1*');
        rc1FileList=[rc1FileList;{[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgNewSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(1).name]}];
        DirImg=dir('rc2*');
        rc2FileList=[rc2FileList;{[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgNewSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(1).name]}];
        cd('..');
    end
    matlabbatch{1,1}.spm.tools.dartel.warp.images{1,1}=rc1FileList;
    matlabbatch{1,1}.spm.tools.dartel.warp.images{1,2}=rc2FileList;
    fprintf(['Running DARTEL: Create Template.\n']);
    spm_jobman('run',matlabbatch);
    
    % DARTEL: Normalize to MNI space - GM, WM, CSF and T1 Images.
    load([ProgramPath,filesep,'Jobmats',filesep,'Dartel_NormaliseToMNI_ManySubjects.mat']);
    cd([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgNewSegment']);
    FlowFieldFileList=[];
    GMFileList=[];
    WMFileList=[];
    CSFFileList=[];
    for i=1:AutoDataProcessParameter.SubjectNum
        cd(AutoDataProcessParameter.SubjectID{i});
        DirImg=dir('u_*');
        FlowFieldFileList=[FlowFieldFileList;{[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgNewSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(1).name]}];
        DirImg=dir('c1*');
        GMFileList=[GMFileList;{[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgNewSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(1).name]}];
        DirImg=dir('c2*');
        WMFileList=[WMFileList;{[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgNewSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(1).name]}];
        DirImg=dir('c3*');
        CSFFileList=[CSFFileList;{[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgNewSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(1).name]}];

        if i==1
            DirImg=dir('Template_6.*');
            TemplateFile={[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgNewSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(1).name]};
        end
        cd('..');
    end
    
    matlabbatch{1,1}.spm.tools.dartel.mni_norm.template=TemplateFile;
    matlabbatch{1,1}.spm.tools.dartel.mni_norm.data.subjs.flowfields=FlowFieldFileList;
    
    matlabbatch{1,1}.spm.tools.dartel.mni_norm.data.subjs.images{1,1}=GMFileList;
    matlabbatch{1,1}.spm.tools.dartel.mni_norm.data.subjs.images{1,2}=WMFileList;
    matlabbatch{1,1}.spm.tools.dartel.mni_norm.data.subjs.images{1,3}=CSFFileList;
    
    fprintf(['Running DARTEL: Normalize to MNI space for VBM. Modulated version With smooth kernel [8 8 8].\n']);
    spm_jobman('run',matlabbatch);
    
    matlabbatch{1,1}.spm.tools.dartel.mni_norm.fwhm=[0 0 0]; % Do not want to perform smooth
    fprintf(['Running DARTEL: Normalize to MNI space for VBM. Modulated version.\n']);
    spm_jobman('run',matlabbatch);
    
    matlabbatch{1,1}.spm.tools.dartel.mni_norm.preserve = 0;
    if exist('T1SourceFileSet','var')
        matlabbatch{1,1}.spm.tools.dartel.mni_norm.data.subjs.images{1,4}=T1SourceFileSet;
    end
    fprintf(['Running DARTEL: Normalize to MNI space for VBM. Unmodulated version.\n']);
    spm_jobman('run',matlabbatch);
    
end


%Normalize
if (AutoDataProcessParameter.IsNormalize>0)
    if (AutoDataProcessParameter.IsNormalize==1) %Normalization by using the EPI template directly
        % Check if mean* image generated in Head Motion Correction exist. Added by YAN Chao-Gan 101010.
        if 7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{1}],'dir')
            DirMean=dir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{1},filesep,'mean*.img']);
            if isempty(DirMean)  %YAN Chao-Gan, 111114. Also support .nii files.
                DirMean=dir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{1},filesep,'mean*.nii']);
            end
        else
            DirMean=[];
        end
        if isempty(DirMean)
            cd([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName]);
            for i=1:AutoDataProcessParameter.SubjectNum
                fprintf('\nCalculate mean functional brain (%s) for "%s" since there is no mean* image generated in Head Motion Correction exist.\n',AutoDataProcessParameter.StartingDirName, AutoDataProcessParameter.SubjectID{i});
                cd(AutoDataProcessParameter.SubjectID{i});
                DirImg=dir('*.img');
                if isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
                    DirImg=dir('*.nii');
                end
                [Data, Header] = rest_ReadNiftiImage(DirImg(1).name);
                AllVolume =repmat(Data, [1,1,1, length(DirImg)]);
                for j=2:length(DirImg)
                    [Data, Header] = rest_ReadNiftiImage(DirImg(j).name);
                    AllVolume(:,:,:,j) = Data;
                    if ~mod(j,5)
                        fprintf('.');
                    end
                end
                AllVolume=mean(AllVolume,4);
                mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i}]);
                Header.pinfo = [1;0;0];
                Header.dt    =[16,0];
                rest_WriteNiftiImage(AllVolume,Header,[AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'mean',AutoDataProcessParameter.SubjectID{i},'img']);
                fprintf('\nMean functional brain (%s) for "%s" saved as: %s\n',AutoDataProcessParameter.StartingDirName, AutoDataProcessParameter.SubjectID{i}, [AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'mean',AutoDataProcessParameter.SubjectID{i},'img']);
                cd('..');
            end
        end
        load([ProgramPath,filesep,'Jobmats',filesep,'Normalize.mat']);
        cd([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName]);
        for i=1:AutoDataProcessParameter.SubjectNum
            FileList=[];
            for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
                cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}]);
                DirImg=dir('*.img');
                if isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
                    DirImg=dir('*.nii');
                end
                if length(DirImg)~=AutoDataProcessParameter.TimePoints
                    Error=[Error;{['Error in Normalize: ',AutoDataProcessParameter.SubjectID{i}]}];
                end
                for j=1:length(DirImg)
                    FileList=[FileList;{[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(j).name,',1']}];
                end
            end

            MeanFilename=dir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'mean*.img']);
            if isempty(MeanFilename)  %YAN Chao-Gan, 111114. Also support .nii files.
                MeanFilename=dir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'mean*.nii']);
            end
            MeanFilename=[AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,MeanFilename.name,',1'];
            if i~=1
                jobs{1,1}.spatial{1,1}.normalise{1,1}.estwrite.subj=[jobs{1,1}.spatial{1,1}.normalise{1,1}.estwrite.subj,jobs{1,1}.spatial{1,1}.normalise{1,1}.estwrite.subj(1,1)];
            end
            jobs{1,1}.spatial{1,1}.normalise{1,1}.estwrite.subj(1,i).source={MeanFilename};
            jobs{1,1}.spatial{1,1}.normalise{1,1}.estwrite.subj(1,i).resample=FileList;
            fprintf(['Normalize Setup:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
        [SPMPath, fileN, extn] = fileparts(which('spm.m'));
        jobs{1,1}.spatial{1,1}.normalise{1,1}.estwrite.eoptions.template={[SPMPath,filesep,'templates',filesep,'EPI.nii,1']};
        jobs{1,1}.spatial{1,1}.normalise{1,1}.estwrite.roptions.bb=AutoDataProcessParameter.Normalize.BoundingBox;
        jobs{1,1}.spatial{1,1}.normalise{1,1}.estwrite.roptions.vox=AutoDataProcessParameter.Normalize.VoxSize;
        if SPMversion==5
            spm_jobman('run',jobs);
        elseif SPMversion==8  %YAN Chao-Gan, 090925. SPM8 compatible.
            jobs = spm_jobman('spm5tospm8',{jobs});
            spm_jobman('run',jobs{1});
        else
            uiwait(msgbox('The current SPM version is not supported by DPARSF. Please install SPM5 or SPM8 first.','Invalid SPM Version.'));
            return
        end
    end
    
    if (AutoDataProcessParameter.IsNormalize==2) %Normalization by using the T1 image segment information
        
        %Normalize-Write: Using the segment information
        load([ProgramPath,filesep,'Jobmats',filesep,'Normalize_Write.mat']);
        cd([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName]);
        for i=1:AutoDataProcessParameter.SubjectNum
            FileList=[];
            for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
                cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}]);
                DirImg=dir('*.img');
                if isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
                    DirImg=dir('*.nii');
                end
                if length(DirImg)~=AutoDataProcessParameter.TimePoints
                    Error=[Error;{['Error in Normalize: ',AutoDataProcessParameter.SubjectID{i}]}];
                end
                for j=1:length(DirImg)
                    FileList=[FileList;{[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(j).name,',1']}];
                end
            end
            
            MatFileDir=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*seg_sn.mat']);
            MatFilename=[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,MatFileDir(1).name];
            if i~=1
                jobs=[jobs,{jobs{1,1}}];
            end
            jobs{1,i}.spatial{1,1}.normalise{1,1}.write.subj.matname={MatFilename};
            jobs{1,i}.spatial{1,1}.normalise{1,1}.write.subj.resample=FileList;
            jobs{1,i}.spatial{1,1}.normalise{1,1}.write.roptions.bb=AutoDataProcessParameter.Normalize.BoundingBox;
            jobs{1,i}.spatial{1,1}.normalise{1,1}.write.roptions.vox=AutoDataProcessParameter.Normalize.VoxSize;
            fprintf(['Normalize-Write Setup:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
        if SPMversion==5
            spm_jobman('run',jobs);
        elseif SPMversion==8  %YAN Chao-Gan, 090925. SPM8 compatible.
            jobs = spm_jobman('spm5tospm8',{jobs});
            spm_jobman('run',jobs{1});
        else
            uiwait(msgbox('The current SPM version is not supported by DPARSF. Please install SPM5 or SPM8 first.','Invalid SPM Version.'));
            return
        end
    end

    if (AutoDataProcessParameter.IsNormalize==3) %Normalization by using DARTEL %YAN Chao-Gan, 111111.
        load([ProgramPath,filesep,'Jobmats',filesep,'Dartel_NormaliseToMNI_FewSubjects.mat']);
        
        matlabbatch{1,1}.spm.tools.dartel.mni_norm.fwhm=[0 0 0];
        matlabbatch{1,1}.spm.tools.dartel.mni_norm.preserve=0;
        matlabbatch{1,1}.spm.tools.dartel.mni_norm.bb=AutoDataProcessParameter.Normalize.BoundingBox;
        matlabbatch{1,1}.spm.tools.dartel.mni_norm.vox=AutoDataProcessParameter.Normalize.VoxSize;
        
        DirImg=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgNewSegment',filesep,AutoDataProcessParameter.SubjectID{1},filesep,'Template_6.*']);
        matlabbatch{1,1}.spm.tools.dartel.mni_norm.template={[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgNewSegment',filesep,AutoDataProcessParameter.SubjectID{1},filesep,DirImg(1).name]};
        
        cd([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName]);
        for i=1:AutoDataProcessParameter.SubjectNum
            FileList=[];
            for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
                cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}]);
                DirImg=dir('*.img');
                if isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
                    DirImg=dir('*.nii');
                end
                if length(DirImg)~=AutoDataProcessParameter.TimePoints
                    Error=[Error;{['Error in Normalize: ',AutoDataProcessParameter.SubjectID{i}]}];
                end
                for j=1:length(DirImg)
                    FileList=[FileList;{[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(j).name]}];
                end
            end
            
            matlabbatch{1,1}.spm.tools.dartel.mni_norm.data.subj(1,i).images=FileList;
            
            DirImg=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgNewSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'u_*']);
            matlabbatch{1,1}.spm.tools.dartel.mni_norm.data.subj(1,i).flowfield={[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgNewSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(1).name]};
            
            fprintf(['Normalization by using DARTEL Setup:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
        spm_jobman('run',matlabbatch);
    end
    
    %Copy the Normalized files to DataProcessDir\{AutoDataProcessParameter.StartingDirName}+W
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName]);
        for i=1:AutoDataProcessParameter.SubjectNum
            cd(AutoDataProcessParameter.SubjectID{i});
            mkdir(['..',filesep,'..',filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'W',filesep,AutoDataProcessParameter.SubjectID{i}])
            movefile('w*',['..',filesep,'..',filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'W',filesep,AutoDataProcessParameter.SubjectID{i}])
            cd('..');
            fprintf(['Moving Normalized Files:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
    end
    
    AutoDataProcessParameter.StartingDirName=[AutoDataProcessParameter.StartingDirName,'W']; %Now StartingDirName is with new suffix 'W'
    
    %Delete files before normalization
    if AutoDataProcessParameter.IsDelFilesBeforeNormalize==1
        for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
            cd(AutoDataProcessParameter.DataProcessDir);
            if (AutoDataProcessParameter.IsSliceTiming==1) || (AutoDataProcessParameter.IsRealign==1)
                rmdir([FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName(1:end-1)],'s')
                if (AutoDataProcessParameter.IsSliceTiming==1) && (AutoDataProcessParameter.IsRealign==1)
                    rmdir([FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName(1:end-2)],'s')
                end
            end
        end
    end
    
    %Generate the pictures for checking normalization %YAN Chao-Gan, 091001
    mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'PicturesForChkNormalization']);
    cd([AutoDataProcessParameter.DataProcessDir,filesep,'PicturesForChkNormalization']);
    if license('test','image_toolbox') % Added by YAN Chao-Gan, 100420.
        global DPARSF_rest_sliceviewer_Cfg;
        h=DPARSF_rest_sliceviewer;
        [RESTPath, fileN, extn] = fileparts(which('rest.m'));
        Ch2Filename=[RESTPath,filesep,'Template',filesep,'ch2.nii'];
        set(DPARSF_rest_sliceviewer_Cfg.Config(1).hOverlayFile, 'String', Ch2Filename);
        DPARSF_rest_sliceviewer_Cfg.Config(1).Overlay.Opacity=0.2;
        DPARSF_rest_sliceviewer('ChangeOverlay', h);
        for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
            for i=1:AutoDataProcessParameter.SubjectNum
                Dir=dir([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
                if isempty(Dir)  %YAN Chao-Gan, 111114. Also support .nii files.
                    Dir=dir([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
                end
                Filename=[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,Dir(1).name];
                % Revised by YAN Chao-Gan, 100420. Fixed a bug in displaying overlay with different bounding box from those of underlay in according to rest_sliceviewer.m
                DPARSF_Normalized_TempImage =fullfile(tempdir,['DPARSF_Normalized_TempImage','_',rest_misc('GetCurrentUser'),'.img']);
                y_Reslice(Filename,DPARSF_Normalized_TempImage,[1 1 1],0)
                set(DPARSF_rest_sliceviewer_Cfg.Config(1).hUnderlayFile, 'String', DPARSF_Normalized_TempImage);
                set(DPARSF_rest_sliceviewer_Cfg.Config(1).hMagnify ,'Value',2);
                %             set(DPARSF_rest_sliceviewer_Cfg.Config(1).hUnderlayFile, 'String', Filename);
                %             set(DPARSF_rest_sliceviewer_Cfg.Config(1).hMagnify ,'Value',4);
                DPARSF_rest_sliceviewer('ChangeUnderlay', h);
                eval(['print(''-dtiff'',''-r100'',''',FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.SubjectID{i},'.tif'',h);']);
                fprintf(['Generating the pictures for checking normalization: ',AutoDataProcessParameter.SubjectID{i},' OK']);
            end
        end
        close(h);
        fprintf('\n');
    else  % Added by YAN Chao-Gan, 100420.
        fprintf('Since Image Processing Toolbox of MATLAB is not valid, the pictures for checking normalization will not be generated.\n');
        fid = fopen('Warning.txt','at+');
        fprintf(fid,'%s','Since Image Processing Toolbox of MATLAB is not valid, the pictures for checking normalization will not be generated.\n');
        fclose(fid);
    end
end
if ~isempty(Error)
    disp(Error);
    return;
end


%Smooth
if (AutoDataProcessParameter.IsSmooth>=1)
    if (AutoDataProcessParameter.IsSmooth==1)
        load([ProgramPath,filesep,'Jobmats',filesep,'Smooth.mat']);
        for i=1:AutoDataProcessParameter.SubjectNum
            FileList=[];
            for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
                cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}]);
                DirImg=dir('*.img');
                if isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
                    DirImg=dir('*.nii');
                end
                if length(DirImg)~=AutoDataProcessParameter.TimePoints
                    Error=[Error;{['Error in Smooth: ',AutoDataProcessParameter.SubjectID{i}]}];
                end
                for j=1:length(DirImg)
                    FileList=[FileList;{[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(j).name,',1']}];
                end
            end
            jobs{1,1}.spatial{1,1}.smooth.data=[jobs{1,1}.spatial{1,1}.smooth.data;FileList];
            fprintf(['Smooth Setup:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
        jobs{1,1}.spatial{1,1}.smooth.fwhm=AutoDataProcessParameter.Smooth.FWHM;
        if SPMversion==5
            spm_jobman('run',jobs);
        elseif SPMversion==8  %YAN Chao-Gan, 090925. SPM8 compatible.
            jobs = spm_jobman('spm5tospm8',{jobs});
            spm_jobman('run',jobs{1});
        else
            uiwait(msgbox('The current SPM version is not supported by DPARSF. Please install SPM5 or SPM8 first.','Invalid SPM Version.'));
            return
        end
    elseif (AutoDataProcessParameter.IsSmooth==2)   %YAN Chao-Gan, 111111. Smooth by DARTEL. The smoothing that is a part of the normalization to MNI space computes these average intensities from the original data, rather than the warped versions. When the data are warped, some voxels will grow and others will shrink. This will change the regional averages, with more weighting towards those voxels that have grows.
        
        load([ProgramPath,filesep,'Jobmats',filesep,'Dartel_NormaliseToMNI_FewSubjects.mat']);
        matlabbatch{1,1}.spm.tools.dartel.mni_norm.fwhm=AutoDataProcessParameter.Smooth.FWHM;
        matlabbatch{1,1}.spm.tools.dartel.mni_norm.preserve=0;
        matlabbatch{1,1}.spm.tools.dartel.mni_norm.bb=AutoDataProcessParameter.Normalize.BoundingBox;
        matlabbatch{1,1}.spm.tools.dartel.mni_norm.vox=AutoDataProcessParameter.Normalize.VoxSize;
        DirImg=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgNewSegment',filesep,AutoDataProcessParameter.SubjectID{1},filesep,'Template_6.*']);
        matlabbatch{1,1}.spm.tools.dartel.mni_norm.template={[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgNewSegment',filesep,AutoDataProcessParameter.SubjectID{1},filesep,DirImg(1).name]};

        for i=1:AutoDataProcessParameter.SubjectNum
            FileList=[];
            for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
                cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName(1:end-1),filesep,AutoDataProcessParameter.SubjectID{i}]); % If smoothed by DARTEL, then the files still under realign directory.
                DirImg=dir('*.img');
                if isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
                    DirImg=dir('*.nii');
                end
                if length(DirImg)~=AutoDataProcessParameter.TimePoints
                    Error=[Error;{['Error in Smooth: ',AutoDataProcessParameter.SubjectID{i}]}];
                end
                for j=1:length(DirImg)
                    FileList=[FileList;{[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName(1:end-1),filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(j).name]}];
                end
            end
            
            matlabbatch{1,1}.spm.tools.dartel.mni_norm.data.subj(1,i).images=FileList;
            DirImg=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgNewSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'u_*']);
            matlabbatch{1,1}.spm.tools.dartel.mni_norm.data.subj(1,i).flowfield={[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgNewSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirImg(1).name]};
            fprintf(['Smooth by using DARTEL Setup:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
        spm_jobman('run',matlabbatch);
        
    end

    %Copy the Smoothed files to DataProcessDir\{AutoDataProcessParameter.StartingDirName}+S
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        if (AutoDataProcessParameter.IsSmooth==1)
            cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName]);
        elseif (AutoDataProcessParameter.IsSmooth==2) % If smoothed by DARTEL, then the smoothed files still under realign directory.
            cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName(1:end-1)]);
        end
        
        for i=1:AutoDataProcessParameter.SubjectNum
            cd(AutoDataProcessParameter.SubjectID{i});
            mkdir(['..',filesep,'..',filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'S',filesep,AutoDataProcessParameter.SubjectID{i}])
            movefile('s*',['..',filesep,'..',filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'S',filesep,AutoDataProcessParameter.SubjectID{i}])
            cd('..');
            fprintf(['Moving Smoothed Files:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
    end
    
    AutoDataProcessParameter.StartingDirName=[AutoDataProcessParameter.StartingDirName,'S']; %Now StartingDirName is with new suffix 'S'
end
if ~isempty(Error)
    disp(Error);
    return;
end


%Detrend
if (AutoDataProcessParameter.IsDetrend==1)
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        for i=1:AutoDataProcessParameter.SubjectNum
            rest_detrend([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}], '_detrend');
        end
    end
    
    %Copy the Detrended files to DataProcessDir\{AutoDataProcessParameter.StartingDirName}+D
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName]);
        for i=1:AutoDataProcessParameter.SubjectNum
            cd([AutoDataProcessParameter.SubjectID{i}, '_detrend']);
            mkdir(['..',filesep,'..',filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'D',filesep,AutoDataProcessParameter.SubjectID{i}])
            movefile('*',['..',filesep,'..',filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'D',filesep,AutoDataProcessParameter.SubjectID{i}])
            cd('..');
            rmdir([AutoDataProcessParameter.SubjectID{i}, '_detrend']);
            fprintf(['Moving Dtrended Files:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
    end
    AutoDataProcessParameter.StartingDirName=[AutoDataProcessParameter.StartingDirName,'D']; %Now StartingDirName is with new suffix 'D'

end



if ~(7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'Masks'],'dir'))
    mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'Masks']);
end

%Calculate ALFF  %YAN Chao-Gan, 111215. Calculate ALFF and fALFF before filtering. 
if (AutoDataProcessParameter.IsCalALFF==1)
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        mkdir([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'ALFF']);
    end
    for i=1:AutoDataProcessParameter.SubjectNum

        % Check if the mask is appropriate
        AMaskFilename=AutoDataProcessParameter.CalALFF.AMaskFilename;
        if (AutoDataProcessParameter.IsWarpMasksIntoIndividualSpace==0)
            if isequal(AMaskFilename, 'Default')
                AMaskFilename=[ProgramPath,filesep,'Templates',filesep,'BrainMask_05_61x73x61.img'];
            end
            if ~isempty(AMaskFilename)
                [MaskData,MaskVox,MaskHeader]=rest_readfile(AMaskFilename);
                RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
                if isempty(RefFile)  %YAN Chao-Gan, 111114. Also support .nii files.
                    RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
                end
                RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefFile(1).name];
                [RefData,RefVox,RefHeader]=rest_readfile(RefFile);
                if ~isequal(size(MaskData), size(RefData))
                    fprintf('\nReslice Brain Mask (%s) for "%s" since the dimension of mask mismatched the dimension of the functional data.\n',AMaskFilename, AutoDataProcessParameter.SubjectID{i});
                    if ~(7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'Masks'],'dir'))
                        mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'Masks']);
                    end
                    ReslicedMaskName=[AutoDataProcessParameter.DataProcessDir,filesep,'Masks',filesep,'BrainMask_05_',AutoDataProcessParameter.SubjectID{i},'.img'];
                    y_Reslice(AMaskFilename,ReslicedMaskName,RefVox,0, RefFile);
                    AMaskFilename=ReslicedMaskName;
                end
            end
        else % Warp to individual space
            if isequal(AMaskFilename, 'Default')
                AMaskFilename=[ProgramPath,filesep,'Templates',filesep,'BrainMask_05_91x109x91.img'];
            end
            if ~isempty(AMaskFilename)
                RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
                if isempty(RefFile)  %YAN Chao-Gan, 111114. Also support .nii files.
                    RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
                end
                RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefFile(1).name];
                MatFileDir=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*seg_inv_sn.mat']);
                MatFilename=[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,MatFileDir(1).name];
                fprintf('\nWarp Brain Mask (%s) for "%s" to individual space using *seg_inv_sn.mat (in T1ImgSegment) genereated by T1 image segmentation.\n',AMaskFilename, AutoDataProcessParameter.SubjectID{i});
                if ~(7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'Masks'],'dir'))
                    mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'Masks']);
                end
                WarpedMaskName=[AutoDataProcessParameter.DataProcessDir,filesep,'Masks',filesep,'BrainMask_05_',AutoDataProcessParameter.SubjectID{i},'.img'];
                y_NormalizeWrite(AMaskFilename,WarpedMaskName,RefFile,MatFilename,0)
                AMaskFilename=WarpedMaskName;
            end
        end
        %AutoDataProcessParameter.CalALFF.AMaskFilename=AMaskFilename;

        % ALFF Calculation
        for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
            alff(         [AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}], ...
                AutoDataProcessParameter.CalALFF.ASamplePeriod, ...
                AutoDataProcessParameter.CalALFF.ALowPass_HighCutoff, ...
                AutoDataProcessParameter.CalALFF.AHighPass_LowCutoff, ...
                AMaskFilename, ...
                [AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'ALFF',filesep,'ALFFMap_',AutoDataProcessParameter.SubjectID{i}]);
            rest_DivideMeanWithinMask([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'ALFF',filesep,'ALFFMap_',AutoDataProcessParameter.SubjectID{i}], ...
                [AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'ALFF',filesep,'mALFFMap_',AutoDataProcessParameter.SubjectID{i}], ...
                AMaskFilename);
            if AutoDataProcessParameter.CalALFF.mALFF_1 == 1
                [Data Vox Head]=rest_readfile([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'ALFF',filesep,'mALFFMap_',AutoDataProcessParameter.SubjectID{i}]);
                Data=Data - 1;
                Head.pinfo = [1;0;0];
                rest_WriteNiftiImage(Data,Head,[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'ALFF',filesep,'mALFF-1_Map_',AutoDataProcessParameter.SubjectID{i}]);
            end
        end
    end
end




%Calculate fALFF
if (AutoDataProcessParameter.IsCalfALFF==1)
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        mkdir([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'fALFF']);
    end
    for i=1:AutoDataProcessParameter.SubjectNum

        % Check if the mask is appropriate
        AMaskFilename=AutoDataProcessParameter.CalfALFF.AMaskFilename;
        if (AutoDataProcessParameter.IsWarpMasksIntoIndividualSpace==0)
            if isequal(AMaskFilename, 'Default')
                AMaskFilename=[ProgramPath,filesep,'Templates',filesep,'BrainMask_05_61x73x61.img'];
            end
            if ~isempty(AMaskFilename)
                [MaskData,MaskVox,MaskHeader]=rest_readfile(AMaskFilename);
                RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
                if isempty(RefFile)  %YAN Chao-Gan, 111114. Also support .nii files.
                    RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
                end
                RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefFile(1).name];
                [RefData,RefVox,RefHeader]=rest_readfile(RefFile);
                if ~isequal(size(MaskData), size(RefData))
                    fprintf('\nReslice Brain Mask (%s) for "%s" since the dimension of mask mismatched the dimension of the functional data.\n',AMaskFilename, AutoDataProcessParameter.SubjectID{i});
                    if ~(7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'Masks'],'dir'))
                        mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'Masks']);
                    end
                    ReslicedMaskName=[AutoDataProcessParameter.DataProcessDir,filesep,'Masks',filesep,'BrainMask_05_',AutoDataProcessParameter.SubjectID{i},'.img'];
                    y_Reslice(AMaskFilename,ReslicedMaskName,RefVox,0, RefFile);
                    AMaskFilename=ReslicedMaskName;
                end
            end
        else % Warp to individual space
            if isequal(AMaskFilename, 'Default')
                AMaskFilename=[ProgramPath,filesep,'Templates',filesep,'BrainMask_05_91x109x91.img'];
            end
            if ~isempty(AMaskFilename)
                RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
                if isempty(RefFile)  %YAN Chao-Gan, 111114. Also support .nii files.
                    RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
                end
                RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefFile(1).name];
                MatFileDir=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*seg_inv_sn.mat']);
                MatFilename=[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,MatFileDir(1).name];
                fprintf('\nWarp Brain Mask (%s) for "%s" to individual space using *seg_inv_sn.mat (in T1ImgSegment) genereated by T1 image segmentation.\n',AMaskFilename, AutoDataProcessParameter.SubjectID{i});
                if ~(7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'Masks'],'dir'))
                    mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'Masks']);
                end
                WarpedMaskName=[AutoDataProcessParameter.DataProcessDir,filesep,'Masks',filesep,'BrainMask_05_',AutoDataProcessParameter.SubjectID{i},'.img'];
                y_NormalizeWrite(AMaskFilename,WarpedMaskName,RefFile,MatFilename,0)
                AMaskFilename=WarpedMaskName;
            end
        end
        % AutoDataProcessParameter.CalfALFF.AMaskFilename=AMaskFilename;
        
        for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
            f_alff(       [AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}], ...
                AutoDataProcessParameter.CalfALFF.ASamplePeriod, ...
                AutoDataProcessParameter.CalfALFF.ALowPass_HighCutoff, ...
                AutoDataProcessParameter.CalfALFF.AHighPass_LowCutoff, ...
                AMaskFilename, ...
                [AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'fALFF',filesep,'fALFFMap_',AutoDataProcessParameter.SubjectID{i}]);
            rest_DivideMeanWithinMask([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'fALFF',filesep,'fALFFMap_',AutoDataProcessParameter.SubjectID{i}], ...
                [AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'fALFF',filesep,'mfALFFMap_',AutoDataProcessParameter.SubjectID{i}], ...
                AMaskFilename);
            if AutoDataProcessParameter.CalfALFF.mfALFF_1 == 1
                [Data Vox Head]=rest_readfile([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'fALFF',filesep,'mfALFFMap_',AutoDataProcessParameter.SubjectID{i}]);
                Data=Data - 1;
                Head.pinfo = [1;0;0];
                rest_WriteNiftiImage(Data,Head,[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'fALFF',filesep,'mfALFF-1_Map_',AutoDataProcessParameter.SubjectID{i}]);
            end
        end
    end
end


%Filter
if (AutoDataProcessParameter.IsFilter==1)
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        for i=1:AutoDataProcessParameter.SubjectNum
            rest_bandpass([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}], ...
                AutoDataProcessParameter.Filter.ASamplePeriod, ...
                AutoDataProcessParameter.Filter.ALowPass_HighCutoff, ...
                AutoDataProcessParameter.Filter.AHighPass_LowCutoff, ...
                AutoDataProcessParameter.Filter.AAddMeanBack, ...   %Revised by YAN Chao-Gan,100420. In according to the change of rest_bandpass.m. %AutoDataProcessParameter.Filter.ARetrend, ...
                AutoDataProcessParameter.Filter.AMaskFilename);
        end
    end
    
    %Copy the Filtered files to DataProcessDir\{AutoDataProcessParameter.StartingDirName}+F
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName]);
        for i=1:AutoDataProcessParameter.SubjectNum
            cd([AutoDataProcessParameter.SubjectID{i}, '_filtered']);
            mkdir(['..',filesep,'..',filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'F',filesep,AutoDataProcessParameter.SubjectID{i}])
            movefile('*',['..',filesep,'..',filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'F',filesep,AutoDataProcessParameter.SubjectID{i}])
            cd('..');
            rmdir([AutoDataProcessParameter.SubjectID{i}, '_filtered']);
            fprintf(['Moving Filtered Files:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
    end
    AutoDataProcessParameter.StartingDirName=[AutoDataProcessParameter.StartingDirName,'F']; %Now StartingDirName is with new suffix 'F'
    
    %delete detrended files
    if (AutoDataProcessParameter.IsDelDetrendedFiles==1) && (AutoDataProcessParameter.IsDetrend==1)
        cd(AutoDataProcessParameter.DataProcessDir);
        for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
            rmdir(FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName(1:end-1),'s')
        end
    end
end


%Calculate ReHo
if (AutoDataProcessParameter.IsCalReHo==1)
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        mkdir([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'ReHo']);
    end
    for i=1:AutoDataProcessParameter.SubjectNum
        
        % Check if the mask is appropriate
        AMaskFilename=AutoDataProcessParameter.CalReHo.AMaskFilename;
        if (AutoDataProcessParameter.IsWarpMasksIntoIndividualSpace==0)
            if isequal(AMaskFilename, 'Default')
                AMaskFilename=[ProgramPath,filesep,'Templates',filesep,'BrainMask_05_61x73x61.img'];
            end
            if ~isempty(AMaskFilename)
                [MaskData,MaskVox,MaskHeader]=rest_readfile(AMaskFilename);
                RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
                if isempty(RefFile)  %YAN Chao-Gan, 111114. Also support .nii files.
                    RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
                end
                RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefFile(1).name];
                [RefData,RefVox,RefHeader]=rest_readfile(RefFile);
                if ~isequal(size(MaskData), size(RefData))
                    fprintf('\nReslice Brain Mask (%s) for "%s" since the dimension of mask mismatched the dimension of the functional data.\n',AMaskFilename, AutoDataProcessParameter.SubjectID{i});
                    if ~(7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'Masks'],'dir'))
                        mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'Masks']);
                    end
                    ReslicedMaskName=[AutoDataProcessParameter.DataProcessDir,filesep,'Masks',filesep,'BrainMask_05_',AutoDataProcessParameter.SubjectID{i},'.img'];
                    y_Reslice(AMaskFilename,ReslicedMaskName,RefVox,0, RefFile);
                    AMaskFilename=ReslicedMaskName;
                end
            end
        else % Warp to individual space
            if isequal(AMaskFilename, 'Default')
                AMaskFilename=[ProgramPath,filesep,'Templates',filesep,'BrainMask_05_91x109x91.img'];
            end
            if ~isempty(AMaskFilename)
                RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
                if isempty(RefFile)  %YAN Chao-Gan, 111114. Also support .nii files.
                    RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
                end
                RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefFile(1).name];
                MatFileDir=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*seg_inv_sn.mat']);
                MatFilename=[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,MatFileDir(1).name];
                fprintf('\nWarp Brain Mask (%s) for "%s" to individual space using *seg_inv_sn.mat (in T1ImgSegment) genereated by T1 image segmentation.\n',AMaskFilename, AutoDataProcessParameter.SubjectID{i});
                if ~(7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'Masks'],'dir'))
                    mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'Masks']);
                end
                WarpedMaskName=[AutoDataProcessParameter.DataProcessDir,filesep,'Masks',filesep,'BrainMask_05_',AutoDataProcessParameter.SubjectID{i},'.img'];
                y_NormalizeWrite(AMaskFilename,WarpedMaskName,RefFile,MatFilename,0)
                AMaskFilename=WarpedMaskName;
            end
        end
        %AutoDataProcessParameter.CalReHo.AMaskFilename=AMaskFilename;
        
        % ReHo Calculation
        for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
            reho(         [AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}], ...
                AutoDataProcessParameter.CalReHo.ClusterNVoxel, ...
                AMaskFilename, ...
                [AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'ReHo',filesep,'ReHoMap_',AutoDataProcessParameter.SubjectID{i}]);
            rest_DivideMeanWithinMask([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'ReHo',filesep,'ReHoMap_',AutoDataProcessParameter.SubjectID{i}], ...
                [AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'ReHo',filesep,'mReHoMap_',AutoDataProcessParameter.SubjectID{i}], ...
                AMaskFilename);
            
            if AutoDataProcessParameter.CalReHo.smReHo == 1
                load([ProgramPath,filesep,'Jobmats',filesep,'Smooth.mat']);
                FileList=[{[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'ReHo',filesep,'mReHoMap_',AutoDataProcessParameter.SubjectID{i},'.img,1']}];
                jobs{1,1}.spatial{1,1}.smooth.data=[jobs{1,1}.spatial{1,1}.smooth.data;FileList];
                jobs{1,1}.spatial{1,1}.smooth.fwhm=AutoDataProcessParameter.Smooth.FWHM;
                if SPMversion==5
                    spm_jobman('run',jobs);
                elseif SPMversion==8  %YAN Chao-Gan, 090925. SPM8 compatible.
                    jobs = spm_jobman('spm5tospm8',{jobs});
                    spm_jobman('run',jobs{1});
                else
                    uiwait(msgbox('The current SPM version is not supported by DPARSF. Please install SPM5 or SPM8 first.','Invalid SPM Version.'));
                    return
                end
            end
            if AutoDataProcessParameter.CalReHo.mReHo_1 == 1
                if AutoDataProcessParameter.CalReHo.smReHo == 1
                    [Data Vox Head]=rest_readfile([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'ReHo',filesep,'smReHoMap_',AutoDataProcessParameter.SubjectID{i}]);
                    Data=Data - 1;
                    Head.pinfo = [1;0;0];
                    rest_WriteNiftiImage(Data,Head,[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'ReHo',filesep,'smReHo-1_Map_',AutoDataProcessParameter.SubjectID{i}]);
                else
                    [Data Vox Head]=rest_readfile([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'ReHo',filesep,'mReHoMap_',AutoDataProcessParameter.SubjectID{i}]);
                    Data=Data - 1;
                    Head.pinfo = [1;0;0];
                    rest_WriteNiftiImage(Data,Head,[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'ReHo',filesep,'mReHo-1_Map_',AutoDataProcessParameter.SubjectID{i}]);
                end
            end
        end
    end
end


%Remove Covaribles 
if (AutoDataProcessParameter.IsCovremove==1)
    %Extract the Covaribles
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        mkdir([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'Covs',filesep])
    end
    %YAN Chao-Gan 091212.
    CovariatesROI=[];
    if (AutoDataProcessParameter.Covremove.WholeBrain==1)
        if (AutoDataProcessParameter.IsWarpMasksIntoIndividualSpace==0)
            CovariatesROI=[CovariatesROI;{[ProgramPath,filesep,'Templates',filesep,'BrainMask_05_61x73x61.img']}];
        else
            CovariatesROI=[CovariatesROI;{[ProgramPath,filesep,'Templates',filesep,'BrainMask_05_91x109x91.img']}];
        end
    end
    if (AutoDataProcessParameter.Covremove.CSF==1)
        if (AutoDataProcessParameter.IsWarpMasksIntoIndividualSpace==0)
            CovariatesROI=[CovariatesROI;{[ProgramPath,filesep,'Templates',filesep,'CsfMask_07_61x73x61.img']}];
        else
            CovariatesROI=[CovariatesROI;{[ProgramPath,filesep,'Templates',filesep,'CsfMask_07_91x109x91.img']}];
        end
    end
    if (AutoDataProcessParameter.Covremove.WhiteMatter==1)
        if (AutoDataProcessParameter.IsWarpMasksIntoIndividualSpace==0)
            CovariatesROI=[CovariatesROI;{[ProgramPath,filesep,'Templates',filesep,'WhiteMask_09_61x73x61.img']}];
        else
            CovariatesROI=[CovariatesROI;{[ProgramPath,filesep,'Templates',filesep,'WhiteMask_09_91x109x91.img']}];
        end
    end
    
    
    CovariatesROI=[CovariatesROI;AutoDataProcessParameter.Covremove.OtherCovariatesROI];
    if ~isempty(CovariatesROI)
        for i=1:AutoDataProcessParameter.SubjectNum
            SubjectCovariatesROI=CovariatesROI;
            
            RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
            if isempty(RefFile)  %YAN Chao-Gan, 111114. Also support .nii files.
                RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
            end
            RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefFile(1).name];
            [RefData,RefVox,RefHeader]=rest_readfile(RefFile);
            % Ball to mask
            for iROI=1:length(SubjectCovariatesROI)
                if rest_SphereROI( 'IsBallDefinition', SubjectCovariatesROI{iROI})
                    if (AutoDataProcessParameter.IsWarpMasksIntoIndividualSpace==0)
                        rest_Y_SphereROI( 'BallDefinition2Mask' , SubjectCovariatesROI{iROI}, size(RefData), RefVox, RefHeader);
                    else
                        [MNIData MNIVox MNIHeader]=rest_readfile([ProgramPath,filesep,'Templates',filesep,'aal.nii']);
                        rest_Y_SphereROI( 'BallDefinition2Mask' , SubjectCovariatesROI{iROI}, size(MNIData), MNIVox, MNIHeader);
                        clear MNIData
                    end
                    CovariateROIMaskName=[AutoDataProcessParameter.DataProcessDir,filesep,'Masks',filesep,'CovariateROI_',num2str(iROI),'_',AutoDataProcessParameter.SubjectID{i}];
                    OldDirTemp=pwd;
                    cd (tempdir);
                    [Data Head]=rest_ReadNiftiImage(['LastSphereMask_',rest_misc('GetCurrentUser'),'.img']);
                    Head.pinfo = [1;0;0];
                    rest_WriteNiftiImage(Data,Head,[CovariateROIMaskName,'.img']);
%                     copyfile(['LastSphereMask_',rest_misc('GetCurrentUser'),'.hdr'],[CovariateROIMaskName,'.hdr']);
%                     copyfile(['LastSphereMask_',rest_misc('GetCurrentUser'),'.img'],[CovariateROIMaskName,'.img']);
                    cd (OldDirTemp);
                    SubjectCovariatesROI{iROI}=[CovariateROIMaskName,'.img'];
                end
            end

            % Check if the ROI mask is appropriate
            for iROI=1:length(SubjectCovariatesROI)
                AMaskFilename=SubjectCovariatesROI{iROI};
                if exist(AMaskFilename,'file')==2
                    if strcmpi(AMaskFilename(end-3:end), '.img')
                        if (AutoDataProcessParameter.IsWarpMasksIntoIndividualSpace==0)
                            [MaskData,MaskVox,MaskHeader]=rest_readfile(AMaskFilename);
                            RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
                            if isempty(RefFile)  %YAN Chao-Gan, 111114. Also support .nii files.
                                RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
                            end
                            RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefFile(1).name];
                            [RefData,RefVox,RefHeader]=rest_readfile(RefFile);
                            if ~isequal(size(MaskData), size(RefData))
                                fprintf('\nReslice Covariate Mask (%s) for "%s" since the dimension of mask mismatched the dimension of the functional data.\n',AMaskFilename, AutoDataProcessParameter.SubjectID{i});
                                if ~(7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'Masks'],'dir'))
                                    mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'Masks']);
                                end
                                ReslicedMaskName=[AutoDataProcessParameter.DataProcessDir,filesep,'Masks',filesep,'CovariateROI_',num2str(iROI),'_',AutoDataProcessParameter.SubjectID{i},'.img'];
                                y_Reslice(AMaskFilename,ReslicedMaskName,RefVox,0, RefFile);
                                AMaskFilename=ReslicedMaskName;
                            end
                        else % Warp to individual space
                            RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
                            if isempty(RefFile)  %YAN Chao-Gan, 111114. Also support .nii files.
                                RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
                            end
                            RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefFile(1).name];
                            MatFileDir=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*seg_inv_sn.mat']);
                            MatFilename=[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,MatFileDir(1).name];
                            fprintf('\nWarp Covariate Mask (%s) for "%s" to individual space using *seg_inv_sn.mat (in T1ImgSegment) genereated by T1 image segmentation.\n',AMaskFilename, AutoDataProcessParameter.SubjectID{i});
                            if ~(7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'Masks'],'dir'))
                                mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'Masks']);
                            end
                            WarpedMaskName=[AutoDataProcessParameter.DataProcessDir,filesep,'Masks',filesep,'CovariateROI_',num2str(iROI),'_',AutoDataProcessParameter.SubjectID{i},'.img'];
                            y_NormalizeWrite(AMaskFilename,WarpedMaskName,RefFile,MatFilename,0)
                            AMaskFilename=WarpedMaskName;
                        end
                        SubjectCovariatesROI{iROI}=AMaskFilename;
                    end
                end
            end
            
            for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
                rest_Y_ExtractROITC([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}], SubjectCovariatesROI,[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'Covs']);
            end
        end
    end
    %YAN Chao-Gan 091212.

    %Remove the Covariables
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        for i=1:AutoDataProcessParameter.SubjectNum
            if (AutoDataProcessParameter.Covremove.HeadMotion==1)
                DirRP=dir([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,FunSessionPrefixSet{iFunSession},'rp*']);
                Covariables=load([AutoDataProcessParameter.DataProcessDir,filesep,'RealignParameter',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirRP.name]);
            else
                Covariables=[];
            end
            if ~isempty(CovariatesROI)
                load([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'Covs',filesep,AutoDataProcessParameter.SubjectID{i},'_ROITimeCourses.mat']);
                Covariables=[Covariables,theROITimeCourses];
            end
            save([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'Covs',filesep,AutoDataProcessParameter.SubjectID{i},'_Covariables.txt'], 'Covariables', '-ASCII', '-DOUBLE','-TABS');
            ACovariablesDef.ort_file=[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'Covs',filesep,AutoDataProcessParameter.SubjectID{i},'_Covariables.txt'];
            ACovariablesDef.polort=0;    % YAN Chao-Gan, 101025. Will not remove linear trend in regressing out covariables step. %ACovariablesDef.polort=1;
            rest_Y_RegressOutCovariables([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}],ACovariablesDef,'_Covremoved')
        end
        fprintf('\n');
    end
    
    %Copy the Covariates Removed files to DataProcessDir\{AutoDataProcessParameter.StartingDirName}+C
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName]);
        for i=1:AutoDataProcessParameter.SubjectNum
            cd([AutoDataProcessParameter.SubjectID{i}, '_Covremoved']);
            mkdir(['..',filesep,'..',filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'C',filesep,AutoDataProcessParameter.SubjectID{i}])
            movefile('*',['..',filesep,'..',filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'C',filesep,AutoDataProcessParameter.SubjectID{i}])
            cd('..');
            rmdir([AutoDataProcessParameter.SubjectID{i}, '_Covremoved']);
            fprintf(['Moving Coviables Removed Files:',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        fprintf('\n');
    end
    AutoDataProcessParameter.StartingDirName=[AutoDataProcessParameter.StartingDirName,'C']; %Now StartingDirName is with new suffix 'C'

end














% Define ROI Interactively
if (AutoDataProcessParameter.IsDefineROIInteractively==1)
    prompt ={'How many ROIs do you want to define interactively?', 'ROI Radius (mm. "0" means define for each ROI seperately): '};
    def	={	'1', ...
        '0', ...
        };
    options.Resize='on';
    options.WindowStyle='modal';
    options.Interpreter='tex';
    answer =inputdlg(prompt, 'Define ROI Interactively', 1, def,options);
    if numel(answer)==2,
        ROINumber_DefinedInteractively =abs(round(str2num(answer{1})));
        ROIRadius_DefinedInteractively =abs(round(str2num(answer{2})));
    end
    ROIRadius_DefinedInteractively=ROIRadius_DefinedInteractively*ones(AutoDataProcessParameter.SubjectNum,ROINumber_DefinedInteractively);
%     ROICenter_DefinedInteractively=zeros(AutoDataProcessParameter.SubjectNum,ROINumber_DefinedInteractively);
    for i=1:AutoDataProcessParameter.SubjectNum
        DirT1ImgCoreg=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
        if isempty(DirT1ImgCoreg)  %YAN Chao-Gan, 111114. Also support .nii files.
            DirT1ImgCoreg=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
        end
        for iROI=1:ROINumber_DefinedInteractively
            fprintf('Define ROI %d interactively for %s: \n',iROI,AutoDataProcessParameter.SubjectID{i});
            global DPARSFA_spm_image_Parameters
            uiwait(DPARSFA_spm_image('init',[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgCoreg',filesep,AutoDataProcessParameter.SubjectID{i},filesep,DirT1ImgCoreg(1).name]));
            ROICenter_DefinedInteractively{i,iROI}=DPARSFA_spm_image_Parameters.pos;
            clear global DPARSFA_spm_image_Parameters
            if ROIRadius_DefinedInteractively(i,iROI)==0
                answer =inputdlg(sprintf('ROI Radius (mm) for ROI %d with %s: \n',iROI,AutoDataProcessParameter.SubjectID{i}), 'Define ROI Interactively', 1, {'0'},options);
                ROIRadius_DefinedInteractively(i,iROI) =abs(round(str2num(answer{1})));
            end
        end
    end
    AutoDataProcessParameter.ROICenter_DefinedInteractively=ROICenter_DefinedInteractively;
    AutoDataProcessParameter.ROIRadius_DefinedInteractively=ROIRadius_DefinedInteractively;
    AutoDataProcessParameter.ROINumber_DefinedInteractively=ROINumber_DefinedInteractively;
end


% Generate the appropriate ROI masks
if (~isempty(AutoDataProcessParameter.CalFC.ROIDef)) || (AutoDataProcessParameter.IsDefineROIInteractively==1)
    if ~isfield(AutoDataProcessParameter,'ROINumber_DefinedInteractively')
        AutoDataProcessParameter.ROINumber_DefinedInteractively=0;
    end
    
    % Check if masks appropriate %This can be used as a function!!!
    for i=1:AutoDataProcessParameter.SubjectNum
        AutoDataProcessParameter.CalFC.ROIDefForEachSubject{i}=AutoDataProcessParameter.CalFC.ROIDef;
        Suffix='FCROI_'; %%!!! Change as in Fuction
        SubjectROI=AutoDataProcessParameter.CalFC.ROIDefForEachSubject{i}; %%!!! Change as in Fuction
        RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
        if isempty(RefFile)  %YAN Chao-Gan, 111114. Also support .nii files.
            RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
        end
        RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefFile(1).name];
        [RefData,RefVox,RefHeader]=rest_readfile(RefFile);
        % Ball to mask
        for iROI=1:length(SubjectROI)
            if rest_SphereROI( 'IsBallDefinition', SubjectROI{iROI})
                if (AutoDataProcessParameter.IsWarpMasksIntoIndividualSpace==0)
                    rest_Y_SphereROI( 'BallDefinition2Mask' , SubjectROI{iROI}, size(RefData), RefVox, RefHeader);
                else
                    [MNIData MNIVox MNIHeader]=rest_readfile([ProgramPath,filesep,'Templates',filesep,'aal.nii']);
                    rest_Y_SphereROI( 'BallDefinition2Mask' , SubjectROI{iROI}, size(MNIData), MNIVox, MNIHeader);
                    clear MNIData
                end
                ROIMaskName=[AutoDataProcessParameter.DataProcessDir,filesep,'Masks',filesep,Suffix,num2str(iROI),'_',AutoDataProcessParameter.SubjectID{i}];
                OldDirTemp=pwd;
                cd (tempdir);
                [Data Head]=rest_ReadNiftiImage(['LastSphereMask_',rest_misc('GetCurrentUser'),'.img']);
                Head.pinfo = [1;0;0];
                rest_WriteNiftiImage(Data,Head,[ROIMaskName,'.img']);
%                 copyfile(['LastSphereMask_',rest_misc('GetCurrentUser'),'.hdr'],[ROIMaskName,'.hdr']);
%                 copyfile(['LastSphereMask_',rest_misc('GetCurrentUser'),'.img'],[ROIMaskName,'.img']);
                cd (OldDirTemp);
                SubjectROI{iROI}=[ROIMaskName,'.img'];
            end
        end

        % Check if the ROI mask is appropriate
        for iROI=1:length(SubjectROI)
            AMaskFilename=SubjectROI{iROI};
            if exist(AMaskFilename,'file')==2
                if strcmpi(AMaskFilename(end-3:end), '.img')
                    if (AutoDataProcessParameter.IsWarpMasksIntoIndividualSpace==0)
                        [MaskData,MaskVox,MaskHeader]=rest_readfile(AMaskFilename);
                        RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
                        if isempty(RefFile)  %YAN Chao-Gan, 111114. Also support .nii files.
                            RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
                        end
                        RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefFile(1).name];
                        [RefData,RefVox,RefHeader]=rest_readfile(RefFile);
                        if ~isequal(size(MaskData), size(RefData))
                            fprintf('\nReslice %s Mask (%s) for "%s" since the dimension of mask mismatched the dimension of the functional data.\n',Suffix,AMaskFilename, AutoDataProcessParameter.SubjectID{i});
                            if ~(7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'Masks'],'dir'))
                                mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'Masks']);
                            end
                            ReslicedMaskName=[AutoDataProcessParameter.DataProcessDir,filesep,'Masks',filesep,Suffix,num2str(iROI),'_',AutoDataProcessParameter.SubjectID{i},'.img'];
                            y_Reslice(AMaskFilename,ReslicedMaskName,RefVox,0, RefFile);
                            AMaskFilename=ReslicedMaskName;
                        end
                    else % Warp to individual space
                        RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
                        if isempty(RefFile)  %YAN Chao-Gan, 111114. Also support .nii files.
                           RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']); 
                        end
                        RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefFile(1).name];
                        MatFileDir=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*seg_inv_sn.mat']);
                        MatFilename=[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,MatFileDir(1).name];
                        fprintf('\nWarp %s Mask (%s) for "%s" to individual space using *seg_inv_sn.mat (in T1ImgSegment) genereated by T1 image segmentation.\n',Suffix,AMaskFilename, AutoDataProcessParameter.SubjectID{i});
                        if ~(7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'Masks'],'dir'))
                            mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'Masks']);
                        end
                        WarpedMaskName=[AutoDataProcessParameter.DataProcessDir,filesep,'Masks',filesep,Suffix,num2str(iROI),'_',AutoDataProcessParameter.SubjectID{i},'.img'];
                        y_NormalizeWrite(AMaskFilename,WarpedMaskName,RefFile,MatFilename,0)
                        AMaskFilename=WarpedMaskName;
                    end
                    SubjectROI{iROI}=AMaskFilename;
                end
            end
        end
        AutoDataProcessParameter.CalFC.ROIDefForEachSubject{i}=SubjectROI; %%!!! Change as in Fuction
        
        
        % Process ROIs defined interactively
        Suffix='ROIDefinedInteractively_'
        for iROI=1:AutoDataProcessParameter.ROINumber_DefinedInteractively
            SubjectROI=rest_SphereROI('ROIBall2Str', AutoDataProcessParameter.ROICenter_DefinedInteractively{i,iROI}, AutoDataProcessParameter.ROIRadius_DefinedInteractively(i,iROI));
            RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
            if isempty(RefFile)  %YAN Chao-Gan, 111114. Also support .nii files.
                RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
            end
            RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefFile(1).name];
            [RefData,RefVox,RefHeader]=rest_readfile(RefFile);
            rest_Y_SphereROI( 'BallDefinition2Mask' , SubjectROI, size(RefData), RefVox, RefHeader);
            ROIMaskName=[AutoDataProcessParameter.DataProcessDir,filesep,'Masks',filesep,Suffix,num2str(iROI),'_',AutoDataProcessParameter.SubjectID{i}];
            OldDirTemp=pwd;
            cd (tempdir);
            [Data Head]=rest_ReadNiftiImage(['LastSphereMask_',rest_misc('GetCurrentUser'),'.img']);
            Head.pinfo = [1;0;0];
            rest_WriteNiftiImage(Data,Head,[ROIMaskName,'.img']);
            cd (OldDirTemp);
            AutoDataProcessParameter.CalFC.ROIDefForEachSubject{i}{length(AutoDataProcessParameter.CalFC.ROIDef)+iROI}=[ROIMaskName,'.img'];
        end
    end
end

%Functional Connectivity Calculation
if (AutoDataProcessParameter.IsCalFC==1)
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        mkdir([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'FC']);
    end

    for i=1:AutoDataProcessParameter.SubjectNum
        % Check if the mask is appropriate
        AMaskFilename=AutoDataProcessParameter.CalFC.AMaskFilename; % !!!Function Change
        if (AutoDataProcessParameter.IsWarpMasksIntoIndividualSpace==0)
            if isequal(AMaskFilename, 'Default')
                AMaskFilename=[ProgramPath,filesep,'Templates',filesep,'BrainMask_05_61x73x61.img'];
            end
            if ~isempty(AMaskFilename)
                [MaskData,MaskVox,MaskHeader]=rest_readfile(AMaskFilename);
                RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
                if isempty(RefFile)  %YAN Chao-Gan, 111114. Also support .nii files.
                    RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
                end
                RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefFile(1).name];
                [RefData,RefVox,RefHeader]=rest_readfile(RefFile);
                if ~isequal(size(MaskData), size(RefData))
                    fprintf('\nReslice Brain Mask (%s) for "%s" since the dimension of mask mismatched the dimension of the functional data.\n',AMaskFilename, AutoDataProcessParameter.SubjectID{i});
                    if ~(7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'Masks'],'dir'))
                        mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'Masks']);
                    end
                    ReslicedMaskName=[AutoDataProcessParameter.DataProcessDir,filesep,'Masks',filesep,'BrainMask_05_',AutoDataProcessParameter.SubjectID{i},'.img'];
                    y_Reslice(AMaskFilename,ReslicedMaskName,RefVox,0, RefFile);
                    AMaskFilename=ReslicedMaskName;
                end
            end
        else % Warp to individual space
            if isequal(AMaskFilename, 'Default')
                AMaskFilename=[ProgramPath,filesep,'Templates',filesep,'BrainMask_05_91x109x91.img'];
            end
            if ~isempty(AMaskFilename)
                RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
                if isempty(RefFile)  %YAN Chao-Gan, 111114. Also support .nii files.
                    RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
                end
                RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefFile(1).name];
                MatFileDir=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*seg_inv_sn.mat']);
                MatFilename=[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,MatFileDir(1).name];
                fprintf('\nWarp Brain Mask (%s) for "%s" to individual space using *seg_inv_sn.mat (in T1ImgSegment) genereated by T1 image segmentation.\n',AMaskFilename, AutoDataProcessParameter.SubjectID{i});
                if ~(7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'Masks'],'dir'))
                    mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'Masks']);
                end
                WarpedMaskName=[AutoDataProcessParameter.DataProcessDir,filesep,'Masks',filesep,'BrainMask_05_',AutoDataProcessParameter.SubjectID{i},'.img'];
                y_NormalizeWrite(AMaskFilename,WarpedMaskName,RefFile,MatFilename,0)
                AMaskFilename=WarpedMaskName;
            end
        end
        %AutoDataProcessParameter.CalFC.AMaskFilename=AMaskFilename; % !!!Function Change
        
        % FC calculation
        for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
            rest_Y_fc(       [AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}], ...
                AMaskFilename, ...
                AutoDataProcessParameter.CalFC.ROIDefForEachSubject{i}, ...
                [AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'FC',filesep,'FCMap_',AutoDataProcessParameter.SubjectID{i}]);
            
            if length(AutoDataProcessParameter.CalFC.ROIDefForEachSubject{i})==1
                rest_Corr2FisherZ([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'FC',filesep,'FCMap_',AutoDataProcessParameter.SubjectID{i}], ...
                    [AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'FC',filesep,'zFCMap_',AutoDataProcessParameter.SubjectID{i}], ...
                    AMaskFilename);
            else
                for j=1:length(AutoDataProcessParameter.CalFC.ROIDefForEachSubject{i}),
                    rest_Corr2FisherZ([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'FC',filesep,'ROI',num2str(j),'FCMap_',AutoDataProcessParameter.SubjectID{i}], ...
                        [AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},'Results',filesep,'FC',filesep,'zROI',num2str(j),'FCMap_',AutoDataProcessParameter.SubjectID{i}], ...
                        AMaskFilename);
                end
            end
        end
    end
end

%Extract REST defined ROI Time Cources
if (AutoDataProcessParameter.IsExtractRESTdefinedROITC==1)
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        mkdir([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'_RESTdefinedROITC',filesep])
        cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'_RESTdefinedROITC',filesep]);
        %Extract the ROI time courses
        for i=1:AutoDataProcessParameter.SubjectNum
            rest_Y_ExtractROITC([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}], AutoDataProcessParameter.CalFC.ROIDefForEachSubject{i},[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'_RESTdefinedROITC']);
        end
    end
end


%Extract AAL Time Cources (90 areas)
if (AutoDataProcessParameter.IsExtractAALTC==1)
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        mkdir([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'_AALTC',filesep])
    end

    for i=1:AutoDataProcessParameter.SubjectNum
        % Check if the mask is appropriate
        if (AutoDataProcessParameter.IsWarpMasksIntoIndividualSpace==0)
            AMaskFilename=[ProgramPath,filesep,'Templates',filesep,'AAL_61x73x61_YCG.nii'];
            if ~isempty(AMaskFilename)
                [MaskData,MaskVox,MaskHeader]=rest_readfile(AMaskFilename);
                RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
                if isempty(RefFile)  %YAN Chao-Gan, 111114. Also support .nii files.
                    RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
                end
                RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefFile(1).name];
                [RefData,RefVox,RefHeader]=rest_readfile(RefFile);
                if ~isequal(size(MaskData), size(RefData))
                    fprintf('\nReslice AAL Mask (%s) for "%s" since the dimension of mask mismatched the dimension of the functional data.\n',AMaskFilename, AutoDataProcessParameter.SubjectID{i});
                    if ~(7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'Masks'],'dir'))
                        mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'Masks']);
                    end
                    ReslicedMaskName=[AutoDataProcessParameter.DataProcessDir,filesep,'Masks',filesep,'AAL_',AutoDataProcessParameter.SubjectID{i},'.img'];
                    y_Reslice(AMaskFilename,ReslicedMaskName,RefVox,0, RefFile);
                    AMaskFilename=ReslicedMaskName;
                end
            end
        else % Warp to individual space
            AMaskFilename=[ProgramPath,filesep,'Templates',filesep,'aal.nii'];
            if ~isempty(AMaskFilename)
                RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.img']);
                if isempty(RefFile)  %YAN Chao-Gan, 111114. Also support .nii files.
                    RefFile=dir([AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*.nii']);
                end
                RefFile=[AutoDataProcessParameter.DataProcessDir,filesep,AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i},filesep,RefFile(1).name];
                MatFileDir=dir([AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,'*seg_inv_sn.mat']);
                MatFilename=[AutoDataProcessParameter.DataProcessDir,filesep,'T1ImgSegment',filesep,AutoDataProcessParameter.SubjectID{i},filesep,MatFileDir(1).name];
                fprintf('\nWarp AAL Mask (%s) for "%s" to individual space using *seg_inv_sn.mat (in T1ImgSegment) genereated by T1 image segmentation.\n',AMaskFilename, AutoDataProcessParameter.SubjectID{i});
                if ~(7==exist([AutoDataProcessParameter.DataProcessDir,filesep,'Masks'],'dir'))
                    mkdir([AutoDataProcessParameter.DataProcessDir,filesep,'Masks']);
                end
                WarpedMaskName=[AutoDataProcessParameter.DataProcessDir,filesep,'Masks',filesep,'AAL_',AutoDataProcessParameter.SubjectID{i},'.img'];
                y_NormalizeWrite(AMaskFilename,WarpedMaskName,RefFile,MatFilename,0)
                AMaskFilename=WarpedMaskName;
            end
        end

        % Generate the time courses
        [AALData, Vox, Head] = rest_readfile(AMaskFilename);
        for iAAL=1:90
            AreaName=['0',num2str(iAAL)];
            AreaName=AreaName(end-1:end);
            eval(['AAL',AreaName,'Index=find(AALData==',num2str(iAAL),');']);
        end

        for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
            cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}]);
            for iAAL=1:90
                AreaName=['0',num2str(iAAL)];
                AreaName=AreaName(end-1:end);
                eval(['AAL',AreaName,'TC=[];']);
            end
            DirImg=dir('*.img');
            if isempty(DirImg)  %YAN Chao-Gan, 111114. Also support .nii files.
                DirImg=dir('*.nii');
            end
            for j=1:AutoDataProcessParameter.TimePoints
                Filename=DirImg(j).name;
                [Data, Vox, Head] = rest_readfile(Filename);
                for iAAL=1:90
                    AreaName=['0',num2str(iAAL)];
                    AreaName=AreaName(end-1:end);
                    eval(['Temp=mean(Data(AAL',AreaName,'Index));']);
                    eval(['AAL',AreaName,'TC=[AAL',AreaName,'TC;Temp];']);
                end
            end
            save([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'_AALTC',filesep,AutoDataProcessParameter.SubjectID{i},'_AALTC.mat'],'-regexp', 'AAL\w\wTC');
            fprintf(['Extract AAL Time Cources: ',AutoDataProcessParameter.SubjectID{i},' OK']);
        end
        
    end
    fprintf('\n');
end


%Extract ROI Time Cources
if (AutoDataProcessParameter.IsExtractROITC==1)
    if (AutoDataProcessParameter.ExtractROITC.IsTalCoordinates==1)
        AutoDataProcessParameter.ExtractROITC.ROICenter=tal2icbm_spm(AutoDataProcessParameter.ExtractROITC.ROICenter);
    end
    ROIDef=[];
    for i=1:size(AutoDataProcessParameter.ExtractROITC.ROICenter,1)
        ROIDef=[ROIDef;{rest_SphereROI('ROIBall2Str', AutoDataProcessParameter.ExtractROITC.ROICenter(i,:), AutoDataProcessParameter.ExtractROITC.ROIRadius)}];
    end
    for iFunSession=1:AutoDataProcessParameter.FunctionalSessionNumber
        mkdir([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'_ROITC',filesep])
        cd([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'_ROITC',filesep]);
        %Extract the ROI time courses
        for i=1:AutoDataProcessParameter.SubjectNum
            rest_Y_ExtractROITC([AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,filesep,AutoDataProcessParameter.SubjectID{i}], ROIDef,[AutoDataProcessParameter.DataProcessDir,filesep,FunSessionPrefixSet{iFunSession},AutoDataProcessParameter.StartingDirName,'_ROITC']);
        end
    end
end


rest_waitbar;  %Added by YAN Chao-Gan 091110. Close the rest waitbar after all the calculation.