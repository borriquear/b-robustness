% Copyright (C) 2004 Yokogawa Electric Corporation, All Rights Reserved.
%
% usage:
%   AD_bit  =   GetMeg160ADbitInfoM( fid )
%
% arguments:
%   fid             : file ID
%
% return values:
%   AD_bit  : AD_bit
% 
% confirmation of revision:
%  GetMeg160ADbitInfoM( Inf ) will show and return revision of this function.