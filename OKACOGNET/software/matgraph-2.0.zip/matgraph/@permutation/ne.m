function tf = ne(p,q)
% test if p ~= q
tf = ~eq(p,q);